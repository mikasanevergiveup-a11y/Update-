# Unified Telegram Bot

Production-ready all-in-one bot merging:

| Module | Source |
|--------|--------|
| **Group Help / Management** | Built from your full command specification |
| **Premium Membership** | Ported from Smart Hub Premium (Node → Python) |
| **Task Groups** | Ported from Group Task Bot (aiogram → Pyrogram) |
| **Music & Voice Chat** | Built from your full Music/VC specification (PyTgCalls ready) |

**Stack:** Python 3.11+ · Pyrogram · asyncpg · PostgreSQL/Supabase · yt-dlp · PyTgCalls · APScheduler

**UI:** Dark premium card layout matching the provided screenshot (User ID / Username / Language / Member Role table + Language / Supported / Developer / Get Started buttons).

---

## Features at a glance

### Premium
- `/start` + `/profile` with remaining hours
- Receipt photo → Admin Confirm/Reject (transaction-safe, `SELECT FOR UPDATE`)
- `/setwave` `/setkpay` `/user` `/broadcastpreuser`
- Auto-expire after 24h (configurable `PREMIUM_DEFAULT_HOURS`)

### Group Help
- Ban / Unban / Mute / Unmute / Kick / Warn system (auto-ban at max warns)
- Pin / Unpin / Del / Purge
- Welcome, Rules, Captcha toggle, Anti-link, Anti-channel
- Custom filters & notes (`#trigger`, `/save`, `/get`)
- Approved-user whitelist

### Task Groups
- Force-join Channel + Chat with ✅ Check
- Rules accept/reject
- Round-robin A/B/C assignment
- Photo → Checker topic → ✓/× decision only then approved
- `/do` `/ndo` daily tracking

### Music / VC
- `/play` `/vplay` `/queue` `/pause` `/resume` `/skip` `/stop`
- `/volume` `/shuffle` `/loop` `/auth` `/unauth`
- `/song` download MP3 · `/lyrics`
- Inline control keyboard
- Queue persisted in DB

---

## Quick start (VPS)

### 1. System packages
```bash
sudo apt update
sudo apt install -y python3.12 python3.12-venv python3-pip ffmpeg git
```

### 2. Clone / unpack
```bash
cd /opt
# place unified-bot folder here
cd unified-bot
python3 -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -r requirements.txt
```

### 3. Database
```bash
# On Supabase SQL editor or local psql:
psql $DATABASE_URL -f migrations/001_initial_schema.sql
```

### 4. Environment
```bash
cp .env.example .env
nano .env
# Fill BOT_TOKEN, API_ID, API_HASH, DATABASE_URL, ADMIN_TELEGRAM_IDS
```

### 5. Run
```bash
# Polling (recommended for VPS)
python -m bot.main

# Or with systemd (see deploy/unified-bot.service)
sudo cp deploy/unified-bot.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now unified-bot
```

### 6. BotFather
- `/setcommands` — paste command list from `docs/COMMANDS.md`
- Disable privacy if group commands must see all messages (`/setprivacy` → Disable)
- Add bot as admin in Admin group, Checker group, Task groups, Music groups

---

## Architecture

```
bot/
├── main.py                 # Entry, handler registration, poller
├── config.py               # pydantic-settings
├── database/db.py          # asyncpg pool, transactions, leases
├── keyboards/common.py     # Dark premium UI
├── utils/messages.py       # Templates matching screenshot
└── modules/
    ├── premium/            # Receipts, confirm/reject, broadcast
    ├── group_help/         # Moderation, filters, anti-spam
    ├── task_group/         # Force-join, assignment, photo review
    └── music/              # Queue, yt-dlp, PyTgCalls hooks
```

Background job: premium expiry poller with DB lease (safe under multi-instance).

---

## Environment variables

See `.env.example`. Critical:

| Variable | Description |
|----------|-------------|
| `BOT_TOKEN` | From @BotFather |
| `API_ID` / `API_HASH` | From my.telegram.org |
| `DATABASE_URL` | Supabase transaction pooler (port 6543) preferred |
| `ADMIN_TELEGRAM_IDS` | Comma-separated numeric IDs |
| `ADMIN_GROUP_ID` | Receipt review group |
| `PREMIUM_DEFAULT_HOURS` | Default 24 |

---

## Tests

```bash
python -m compileall -q bot
# Unit tests (when DB available)
pytest -q tests/ || true
```

Smoke: start the bot and hit `/ping`, `/start`, `/profile`.

---

## Documentation

- `docs/FEATURE_INVENTORY.md` — how each original bot was merged
- `docs/COMMANDS.md` — full command reference
- `docs/ADMIN_SETUP.md` — step-by-step admin configuration
- `docs/SUPABASE_SETUP.md` — database setup
- `docs/MISSING_SOURCE_BOTS.md` — none (all 4 modules implemented from source or your specs)
- `docs/KNOWN_LIMITATIONS.md`

---

## License

Private / as agreed with the project owner.
