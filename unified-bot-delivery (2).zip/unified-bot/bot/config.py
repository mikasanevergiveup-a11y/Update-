"""Application configuration loaded from environment."""
from __future__ import annotations

import os
from functools import lru_cache
from typing import List, Optional

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Telegram
    bot_token: str
    api_id: int = 0
    api_hash: str = ""
    session_name: str = "unified_bot"
    string_session: str = ""  # Pyrogram user account StringSession for VC

    # Database
    database_url: str
    supabase_url: Optional[str] = None
    supabase_service_role_key: Optional[str] = None

    # Admins & groups
    admin_telegram_ids: str = ""
    admin_group_id: Optional[str] = None
    check_group_id: Optional[str] = None

    # Premium
    premium_default_hours: int = 24
    plan_price: int = 200

    # Webhook (optional)
    webhook_base_url: Optional[str] = None
    webhook_secret: Optional[str] = None
    webhook_path: str = "/webhook"

    # Runtime
    timezone: str = "Asia/Yangon"
    poll_interval_seconds: int = 60
    log_level: str = "INFO"
    port: int = 8080

    # Music
    max_active_vc: int = 50
    ytdl_opts: str = ""

    @property
    def admin_ids(self) -> List[int]:
        if not self.admin_telegram_ids.strip():
            return []
        return [int(x.strip()) for x in self.admin_telegram_ids.split(",") if x.strip().isdigit()]

    @property
    def use_webhook(self) -> bool:
        return bool(self.webhook_base_url and self.webhook_secret)

    def is_admin(self, user_id: int) -> bool:
        return user_id in self.admin_ids


@lru_cache
def get_settings() -> Settings:
    return Settings()
