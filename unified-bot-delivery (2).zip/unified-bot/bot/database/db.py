"""Async PostgreSQL helpers with connection pool and transactions."""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from typing import Any, AsyncIterator, Dict, List, Optional, Tuple

import asyncpg

from bot.config import get_settings

log = logging.getLogger(__name__)

_pool: Optional[asyncpg.Pool] = None


async def init_pool() -> asyncpg.Pool:
    global _pool
    if _pool is not None:
        return _pool
    settings = get_settings()
    _pool = await asyncpg.create_pool(
        dsn=settings.database_url,
        min_size=2,
        max_size=20,
        command_timeout=30,
        statement_cache_size=0,  # better for PgBouncer transaction mode
    )
    log.info("Database pool created")
    return _pool


async def close_pool() -> None:
    global _pool
    if _pool:
        await _pool.close()
        _pool = None
        log.info("Database pool closed")


@asynccontextmanager
async def acquire() -> AsyncIterator[asyncpg.Connection]:
    pool = await init_pool()
    async with pool.acquire() as conn:
        yield conn


@asynccontextmanager
async def transaction() -> AsyncIterator[asyncpg.Connection]:
    async with acquire() as conn:
        async with conn.transaction():
            yield conn


# ------------------------------------------------------------------
# Users
# ------------------------------------------------------------------

async def upsert_user(
    telegram_id: int,
    username: Optional[str] = None,
    first_name: Optional[str] = None,
    last_name: Optional[str] = None,
    language_code: Optional[str] = None,
) -> Dict[str, Any]:
    full_name = " ".join(filter(None, [first_name or "", last_name or ""])).strip() or "User"
    async with acquire() as conn:
        row = await conn.fetchrow(
            """
            INSERT INTO users (telegram_id, username, first_name, last_name, full_name, language_code, last_seen_at)
            VALUES ($1, $2, $3, $4, $5, $6, now())
            ON CONFLICT (telegram_id) DO UPDATE SET
                username = COALESCE(EXCLUDED.username, users.username),
                first_name = COALESCE(EXCLUDED.first_name, users.first_name),
                last_name = COALESCE(EXCLUDED.last_name, users.last_name),
                full_name = COALESCE(EXCLUDED.full_name, users.full_name),
                language_code = COALESCE(EXCLUDED.language_code, users.language_code),
                last_seen_at = now(),
                updated_at = now()
            RETURNING *
            """,
            telegram_id, username, first_name, last_name, full_name, language_code or "en",
        )
        return dict(row)


async def get_user(telegram_id: int) -> Optional[Dict[str, Any]]:
    async with acquire() as conn:
        row = await conn.fetchrow("SELECT * FROM users WHERE telegram_id = $1", telegram_id)
        return dict(row) if row else None


async def set_premium(telegram_id: int, hours: int) -> Dict[str, Any]:
    """Extend or set premium. Transaction-safe."""
    async with transaction() as conn:
        row = await conn.fetchrow(
            "SELECT is_premium, premium_until FROM users WHERE telegram_id = $1 FOR UPDATE",
            telegram_id,
        )
        now = datetime.now(timezone.utc)
        base = now
        if row and row["is_premium"] and row["premium_until"] and row["premium_until"] > now:
            base = row["premium_until"]
        new_until = base + timedelta(hours=hours)
        updated = await conn.fetchrow(
            """
            UPDATE users SET is_premium = TRUE, premium_until = $2, updated_at = now()
            WHERE telegram_id = $1 RETURNING *
            """,
            telegram_id, new_until,
        )
        return dict(updated)


async def expire_premiums() -> int:
    """Mark expired premiums as free. Returns number of rows updated."""
    async with acquire() as conn:
        result = await conn.execute(
            """
            UPDATE users SET is_premium = FALSE, updated_at = now()
            WHERE is_premium = TRUE AND premium_until IS NOT NULL AND premium_until <= now()
            """
        )
        # result is like "UPDATE 5"
        return int(result.split()[-1]) if result else 0


async def remaining_hours(telegram_id: int) -> float:
    async with acquire() as conn:
        val = await conn.fetchval(
            """
            SELECT CASE
                WHEN premium_until IS NULL OR premium_until <= now() THEN 0
                ELSE EXTRACT(EPOCH FROM (premium_until - now())) / 3600.0
            END FROM users WHERE telegram_id = $1
            """,
            telegram_id,
        )
        return float(val or 0)


# ------------------------------------------------------------------
# Settings
# ------------------------------------------------------------------

async def get_setting(key: str, default: Optional[str] = None) -> Optional[str]:
    async with acquire() as conn:
        val = await conn.fetchval("SELECT value FROM bot_settings WHERE key = $1", key)
        return val if val is not None else default


async def set_setting(key: str, value: str) -> None:
    async with acquire() as conn:
        await conn.execute(
            """
            INSERT INTO bot_settings (key, value, updated_at) VALUES ($1, $2, now())
            ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()
            """,
            key, value,
        )


async def get_all_settings() -> Dict[str, str]:
    async with acquire() as conn:
        rows = await conn.fetch("SELECT key, value FROM bot_settings")
        return {r["key"]: r["value"] for r in rows}


# ------------------------------------------------------------------
# Premium receipts (transaction-safe confirm/reject)
# ------------------------------------------------------------------

async def create_receipt(
    telegram_id: int,
    photo_file_id: str,
    photo_file_unique_id: Optional[str],
    hours: int = 24,
) -> Optional[Dict[str, Any]]:
    async with acquire() as conn:
        try:
            row = await conn.fetchrow(
                """
                INSERT INTO premium_receipts
                    (telegram_id, status, photo_file_id, photo_file_unique_id, premium_hours)
                VALUES ($1, 'pending', $2, $3, $4)
                RETURNING *
                """,
                telegram_id, photo_file_id, photo_file_unique_id, hours,
            )
            return dict(row)
        except asyncpg.UniqueViolationError:
            return None  # duplicate


async def get_pending_receipt(telegram_id: int) -> Optional[Dict[str, Any]]:
    async with acquire() as conn:
        row = await conn.fetchrow(
            """
            SELECT * FROM premium_receipts
            WHERE telegram_id = $1 AND status = 'pending'
            ORDER BY created_at DESC LIMIT 1
            """,
            telegram_id,
        )
        return dict(row) if row else None


async def confirm_receipt(
    receipt_id: int,
    reviewer_id: int,
    admin_chat_id: int,
    admin_message_id: int,
) -> Optional[Dict[str, Any]]:
    """Atomic confirm + grant premium. Returns user row or None if already resolved."""
    async with transaction() as conn:
        receipt = await conn.fetchrow(
            """
            SELECT * FROM premium_receipts
            WHERE id = $1 AND status = 'pending'
            FOR UPDATE
            """,
            receipt_id,
        )
        if not receipt:
            return None
        hours = receipt["premium_hours"] or 24
        now = datetime.now(timezone.utc)
        user = await conn.fetchrow(
            "SELECT is_premium, premium_until FROM users WHERE telegram_id = $1 FOR UPDATE",
            receipt["telegram_id"],
        )
        base = now
        if user and user["is_premium"] and user["premium_until"] and user["premium_until"] > now:
            base = user["premium_until"]
        new_until = base + timedelta(hours=hours)
        await conn.execute(
            """
            UPDATE premium_receipts SET
                status = 'confirmed', reviewer_id = $2, reviewed_at = now(),
                admin_chat_id = $3, admin_message_id = $4
            WHERE id = $1
            """,
            receipt_id, reviewer_id, admin_chat_id, admin_message_id,
        )
        updated_user = await conn.fetchrow(
            """
            UPDATE users SET is_premium = TRUE, premium_until = $2, updated_at = now()
            WHERE telegram_id = $1 RETURNING *
            """,
            receipt["telegram_id"], new_until,
        )
        await conn.execute(
            """
            INSERT INTO premium_transactions (telegram_id, receipt_id, hours_added, premium_until)
            VALUES ($1, $2, $3, $4)
            """,
            receipt["telegram_id"], receipt_id, hours, new_until,
        )
        return dict(updated_user) if updated_user else None


async def reject_receipt(
    receipt_id: int,
    reviewer_id: int,
    admin_chat_id: int,
    admin_message_id: int,
) -> bool:
    async with transaction() as conn:
        result = await conn.execute(
            """
            UPDATE premium_receipts SET
                status = 'rejected', reviewer_id = $2, reviewed_at = now(),
                admin_chat_id = $3, admin_message_id = $4
            WHERE id = $1 AND status = 'pending'
            """,
            receipt_id, reviewer_id, admin_chat_id, admin_message_id,
        )
        return result.endswith("1")


# ------------------------------------------------------------------
# Task group helpers
# ------------------------------------------------------------------

async def next_task_group() -> str:
    async with transaction() as conn:
        row = await conn.fetchrow(
            "SELECT counter FROM round_robin_state WHERE id = 1 FOR UPDATE"
        )
        counter = (row["counter"] if row else 0) + 1
        await conn.execute(
            "UPDATE round_robin_state SET counter = $1 WHERE id = 1", counter
        )
        return ["A", "B", "C"][(counter - 1) % 3]


async def assign_task_group(telegram_id: int, group: str) -> None:
    async with acquire() as conn:
        await conn.execute(
            "UPDATE users SET assigned_task_group = $2, updated_at = now() WHERE telegram_id = $1",
            telegram_id, group,
        )


# ------------------------------------------------------------------
# Audit
# ------------------------------------------------------------------

async def audit(
    admin_id: int,
    action: str,
    target_id: Optional[int] = None,
    chat_id: Optional[int] = None,
    metadata: Optional[Dict] = None,
) -> None:
    import json
    async with acquire() as conn:
        await conn.execute(
            """
            INSERT INTO admin_audit_logs (admin_telegram_id, action, target_telegram_id, chat_id, metadata)
            VALUES ($1, $2, $3, $4, $5::jsonb)
            """,
            admin_id, action, target_id, chat_id, json.dumps(metadata or {}),
        )


# ------------------------------------------------------------------
# Stats
# ------------------------------------------------------------------

async def user_stats() -> Dict[str, int]:
    async with acquire() as conn:
        total = await conn.fetchval("SELECT COUNT(*) FROM users") or 0
        premium = await conn.fetchval(
            "SELECT COUNT(*) FROM users WHERE is_premium = TRUE AND premium_until > now()"
        ) or 0
        pending = await conn.fetchval(
            "SELECT COUNT(*) FROM premium_receipts WHERE status = 'pending'"
        ) or 0
        return {"total": total, "premium": premium, "pending": pending}


# ------------------------------------------------------------------
# Poller lease (idempotent jobs)
# ------------------------------------------------------------------

async def acquire_lease(job_name: str, worker_id: str, lease_seconds: int = 90) -> bool:
    async with acquire() as conn:
        now = datetime.now(timezone.utc)
        lease_until = now + timedelta(seconds=lease_seconds)
        result = await conn.execute(
            """
            INSERT INTO poller_checkpoints (job_name, last_run_at, lease_until, locked_by)
            VALUES ($1, $2, $3, $4)
            ON CONFLICT (job_name) DO UPDATE SET
                last_run_at = EXCLUDED.last_run_at,
                lease_until = EXCLUDED.lease_until,
                locked_by = EXCLUDED.locked_by
            WHERE poller_checkpoints.lease_until IS NULL
               OR poller_checkpoints.lease_until < $2
            """,
            job_name, now, lease_until, worker_id,
        )
        return result.endswith("1")


async def release_lease(job_name: str, worker_id: str) -> None:
    async with acquire() as conn:
        await conn.execute(
            """
            UPDATE poller_checkpoints SET lease_until = NULL
            WHERE job_name = $1 AND locked_by = $2
            """,
            job_name, worker_id,
        )
