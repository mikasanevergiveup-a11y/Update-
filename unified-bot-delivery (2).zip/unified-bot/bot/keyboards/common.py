"""
Capsule / pill buttons — Telegram Bot API 9.4+

style:
  primary  → blue   (Language, main actions)
  success  → green  (Supported, Confirm, Approve)
  danger   → red    (Developer link accent, Reject, Ban)

+ icon_custom_emoji_id (premium animated icons)

Screenshot match:
  [ Language  ] primary + globe
  [ Supported ] success + search
  [ Developer ] danger  + robot
"""
from __future__ import annotations

from typing import Optional

from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from bot.utils.custom_emoji import _load, _ids

CHANNEL_ARCADE = "https://t.me/SmartArcade"
CHANNEL_CODEDROP = "https://t.me/smarthub_codedrop"
CHAT_ARCADE = "https://t.me/SmartArcade_chat"
HUB_BOT = "http://t.me/CandyHub8_bot/start"
DEV_URL = "https://t.me/Mount_lvy"

# Styles
PRIMARY = "primary"   # blue capsule
SUCCESS = "success"   # green capsule
DANGER = "danger"     # red capsule


def _eid(role: str) -> Optional[str]:
    _load()
    return _ids.get(role) or None


def _btn(
    text: str,
    *,
    callback_data: Optional[str] = None,
    url: Optional[str] = None,
    icon_role: Optional[str] = None,
    style: Optional[str] = None,
) -> InlineKeyboardButton:
    """
    Capsule button with optional color style + premium icon.
    Works on Bot API 9.4+; older clients ignore style/icon gracefully.
    """
    kwargs = {}
    if callback_data is not None:
        kwargs["callback_data"] = callback_data
    if url is not None:
        kwargs["url"] = url

    eid = _eid(icon_role) if icon_role else None

    # Prefer full constructor (newer pyrogram / forks)
    for attempt in (
        {"style": style, "icon_custom_emoji_id": eid},
        {"icon_custom_emoji_id": eid},
        {"style": style},
        {},
    ):
        clean = {k: v for k, v in attempt.items() if v}
        try:
            btn = InlineKeyboardButton(text=text, **kwargs, **clean)
            # Ensure attributes exist for HTTP serializers that read them
            if style and not getattr(btn, "style", None):
                try:
                    setattr(btn, "style", style)
                except Exception:
                    pass
            if eid and not getattr(btn, "icon_custom_emoji_id", None):
                try:
                    setattr(btn, "icon_custom_emoji_id", eid)
                except Exception:
                    pass
            return btn
        except TypeError:
            continue

    return InlineKeyboardButton(text=text, **kwargs)


def profile_buttons(lang: str = "my") -> InlineKeyboardMarkup:
    """Exact screenshot row: blue Language | green Supported | red Developer."""
    return InlineKeyboardMarkup(
        [
            [
                _btn("Language", callback_data="profile:lang", icon_role="lang", style=PRIMARY),
                _btn("Supported", callback_data="profile:supported", icon_role="search", style=SUCCESS),
                _btn("Developer", url=DEV_URL, icon_role="developer", style=DANGER),
            ],
            [
                _btn("Back", callback_data="start:welcome", icon_role="back", style=PRIMARY),
            ],
        ]
    )


def main_menu(is_premium: bool = False, is_admin: bool = False, lang: str = "my") -> InlineKeyboardMarkup:
    rows = [
        [
            _btn("Profile", callback_data="menu:profile", icon_role="profile", style=PRIMARY),
            _btn("Premium", callback_data="menu:premium", icon_role="diamond", style=SUCCESS),
        ],
        [
            _btn("Music", callback_data="menu:music", icon_role="music", style=PRIMARY),
            _btn("Group Help", callback_data="menu:grouphelp", icon_role="shield", style=PRIMARY),
        ],
        [
            _btn("Task Groups", callback_data="menu:tasks", icon_role="task", style=SUCCESS),
            _btn("Help", callback_data="menu:help", icon_role="help", style=PRIMARY),
        ],
    ]
    if is_admin:
        rows.append([_btn("Admin", callback_data="menu:admin", icon_role="admin", style=DANGER)])
    return InlineKeyboardMarkup(rows)


def supported_buttons() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [_btn("Smart Hub Platform", callback_data="supported:hub", icon_role="rocket", style=PRIMARY)],
            [_btn("Back", callback_data="menu:profile", icon_role="back", style=PRIMARY)],
        ]
    )


def force_join_buttons() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [_btn("Channel · SmartArcade", url=CHANNEL_ARCADE, icon_role="channel", style=PRIMARY)],
            [_btn("Channel · CodeDrop", url=CHANNEL_CODEDROP, icon_role="channel", style=PRIMARY)],
            [_btn("Chat · SmartArcade", url=CHAT_ARCADE, icon_role="chat", style=SUCCESS)],
            [_btn("Check", callback_data="forcejoin:check", icon_role="check", style=SUCCESS)],
        ]
    )


def terms_buttons(lang: str = "my") -> InlineKeyboardMarkup:
    from bot.utils.i18n import t
    agree = t(lang, "agree").replace("✅ ", "").replace("{e_check} ", "").strip() or "Agree"
    disagree = t(lang, "disagree").replace("❌ ", "").replace("{e_cross} ", "").strip() or "Disagree"
    return InlineKeyboardMarkup(
        [
            [
                _btn(agree, callback_data="terms:agree", icon_role="agree", style=SUCCESS),
                _btn(disagree, callback_data="terms:disagree", icon_role="disagree", style=DANGER),
            ]
        ]
    )


def hub_platform_button(lang: str = "my") -> InlineKeyboardMarkup:
    from bot.utils.i18n import t
    text = t(lang, "hub_btn").replace("🚀 ", "").replace("{e_rocket} ", "").strip() or "Smart Hub Platform"
    return InlineKeyboardMarkup(
        [[_btn(text, url=HUB_BOT, icon_role="rocket", style=PRIMARY)]]
    )


def payment_method_buttons(lang: str = "my") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [
                _btn("Wave Pay", callback_data="pay:wave", icon_role="money", style=SUCCESS),
                _btn("KPay", callback_data="pay:kpay", icon_role="wallet", style=SUCCESS),
            ],
            [_btn("Back", callback_data="start:welcome", icon_role="back", style=PRIMARY)],
        ]
    )


def receipt_admin_buttons(receipt_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [
                _btn("Confirm", callback_data=f"receipt:confirm:{receipt_id}", icon_role="check", style=SUCCESS),
                _btn("Reject", callback_data=f"receipt:reject:{receipt_id}", icon_role="cross", style=DANGER),
            ]
        ]
    )


def music_controls(chat_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [
                _btn("Pause", callback_data=f"music:pause:{chat_id}", icon_role="stop", style=PRIMARY),
                _btn("Resume", callback_data=f"music:resume:{chat_id}", icon_role="play", style=SUCCESS),
                _btn("Skip", callback_data=f"music:skip:{chat_id}", icon_role="skip", style=PRIMARY),
                _btn("Stop", callback_data=f"music:stop:{chat_id}", icon_role="cross", style=DANGER),
            ],
            [
                _btn("Mute", callback_data=f"music:mute:{chat_id}", icon_role="mute", style=DANGER),
                _btn("Unmute", callback_data=f"music:unmute:{chat_id}", icon_role="volume", style=SUCCESS),
                _btn("Queue", callback_data=f"music:queue:{chat_id}", icon_role="list", style=PRIMARY),
            ],
        ]
    )


def task_review_buttons(review_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [
                _btn("Approve", callback_data=f"task:approve:{review_id}", icon_role="check", style=SUCCESS),
                _btn("Reject", callback_data=f"task:reject:{review_id}", icon_role="cross", style=DANGER),
            ]
        ]
    )


def language_buttons() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [
                _btn("မြန်မာ", callback_data="lang:my", icon_role="globe", style=PRIMARY),
                _btn("English", callback_data="lang:en", icon_role="globe", style=SUCCESS),
            ],
            [_btn("Back", callback_data="menu:profile", icon_role="back", style=PRIMARY)],
        ]
    )


def help_modules() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [[_btn("Back", callback_data="start:welcome", icon_role="back", style=PRIMARY)]]
    )


def markup_api_dict(markup: InlineKeyboardMarkup) -> dict:
    """Serialize keyboard including Bot API 9.4 style + icon fields."""
    rows = []
    for row in markup.inline_keyboard:
        out_row = []
        for b in row:
            d: dict = {"text": b.text}
            if getattr(b, "callback_data", None):
                d["callback_data"] = b.callback_data
            if getattr(b, "url", None):
                d["url"] = b.url
            style = getattr(b, "style", None)
            if style:
                d["style"] = style
            icon = getattr(b, "icon_custom_emoji_id", None)
            if icon:
                d["icon_custom_emoji_id"] = str(icon)
            out_row.append(d)
        rows.append(out_row)
    return {"inline_keyboard": rows}
