"""
Unified Telegram Bot — entry point
Modules: Group Help · Premium · Task Groups · Music/VC
"""
from __future__ import annotations

import asyncio
import logging
import signal
import sys
from pathlib import Path

from pyrogram import Client, enums, filters, idle
from pyrogram.handlers import CallbackQueryHandler, MessageHandler
from pyrogram.types import Message, CallbackQuery

# Ensure project root on path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from bot.config import get_settings
from bot.database import db
from bot.keyboards.common import main_menu, help_modules, profile_buttons, language_buttons
from bot.utils.i18n import t, user_lang
from bot.utils.messages import welcome_text, help_text, profile_card, help_all_commands, help_admin_panel

# Module handlers
from bot.modules.premium import handlers as premium
from bot.modules.group_help import handlers as group_help
from bot.modules.task_group import handlers as task_group
from bot.modules.music import handlers as music
from bot.modules.music import vc

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("unified-bot")


def create_app() -> Client:
    settings = get_settings()
    if not settings.api_id or not settings.api_hash:
        # Fallback: bot-only mode still works for most features
        log.warning("API_ID/API_HASH missing — using bot token only (limited user features)")
    app = Client(
        name=settings.session_name,
        api_id=settings.api_id or 6,
        api_hash=settings.api_hash or "eb06d4abfb49dc3eeb1aeb98ae0f581e",
        bot_token=settings.bot_token,
        workdir=str(ROOT),
        in_memory=False,
    )
    return app


# ------------------------------------------------------------------
# Core commands
# ------------------------------------------------------------------

async def cmd_start(client: Client, message: Message) -> None:
    await db.upsert_user(
        message.from_user.id,
        message.from_user.username,
        message.from_user.first_name,
        message.from_user.last_name,
        message.from_user.language_code,
    )
    settings = get_settings()
    is_admin = settings.is_admin(message.from_user.id)
    user = await db.get_user(message.from_user.id)
    is_prem = bool(user and user.get("is_premium"))
    lang = await user_lang(message.from_user.id)
    me = await client.get_me()
    await message.reply_text(
        welcome_text(me.username or "UnifiedBot", lang),
        reply_markup=main_menu(is_prem, is_admin, lang),
        disable_web_page_preview=True,
        parse_mode=enums.ParseMode.HTML,
    )


async def cmd_help(client: Client, message: Message) -> None:
    lang = await user_lang(message.from_user.id)
    await message.reply_text(
        help_all_commands(lang), reply_markup=help_modules(),
        disable_web_page_preview=True, parse_mode=enums.ParseMode.HTML,
    )


async def cmd_helpadminpanel(client: Client, message: Message) -> None:
    settings = get_settings()
    if not settings.is_admin(message.from_user.id):
        await message.reply_text("Admin only.")
        return
    await message.reply_text(help_admin_panel(), disable_web_page_preview=True)


async def cmd_ping(client: Client, message: Message) -> None:
    import time
    lang = await user_lang(message.from_user.id)
    t0 = time.perf_counter()
    m = await message.reply_text("…")
    dt = (time.perf_counter() - t0) * 1000
    await m.edit_text(t(lang, "pong", ms=dt), parse_mode=enums.ParseMode.HTML)


async def on_callback(client: Client, callback: CallbackQuery) -> None:
    data = callback.data or ""
    # Route
    if data.startswith("receipt:"):
        await premium.on_receipt_callback(client, callback)
        return
    if data.startswith("task:"):
        await task_group.on_task_review_callback(client, callback)
        return
    if data.startswith("music:"):
        await music.on_music_callback(client, callback)
        return
    if data.startswith("rules:"):
        await task_group.on_rules_callback(client, callback)
        return
    if data.startswith("menu:") or data.startswith("profile:") or data.startswith("start:") or data.startswith("help:") or data.startswith("lang:") or data.startswith("supported:") or data.startswith("terms:") or data.startswith("pay:") or data == "forcejoin:check":
        await handle_ui_callback(client, callback)
        return
    await callback.answer()



async def handle_ui_callback(client: Client, callback: CallbackQuery) -> None:
    data = callback.data or ""
    settings = get_settings()
    uid = callback.from_user.id
    lang = await user_lang(uid)

    async def edit(text: str, markup=None):
        try:
            await callback.message.edit_text(
                text, reply_markup=markup, disable_web_page_preview=True,
                parse_mode=enums.ParseMode.HTML,
            )
        except Exception:
            await callback.message.reply_text(
                text, reply_markup=markup, disable_web_page_preview=True,
                parse_mode=enums.ParseMode.HTML,
            )

    # Language
    if data == "profile:lang":
        await edit(t(lang, "choose_lang"), language_buttons())
        await callback.answer()
        return
    if data.startswith("lang:"):
        new_lang = data.split(":")[1]
        async with db.acquire() as conn:
            await conn.execute(
                "UPDATE users SET language_code = $2, updated_at = now() WHERE telegram_id = $1",
                uid, new_lang,
            )
        lang = new_lang
        await callback.answer()
        user = await db.get_user(uid)
        remaining = await db.remaining_hours(uid)
        await edit(profile_card(user or {}, remaining, lang), profile_buttons(lang))
        # also confirm
        await callback.message.reply_text(
            t(lang, "lang_set"), parse_mode=enums.ParseMode.HTML
        )
        return

    # Profile
    if data in ("menu:profile", "profile:get_started"):
        user = await db.get_user(uid) or await db.upsert_user(
            uid, callback.from_user.username, callback.from_user.first_name, callback.from_user.last_name
        )
        remaining = await db.remaining_hours(uid)
        await edit(profile_card(user, remaining, lang), profile_buttons(lang))
        await callback.answer()
        return

    # Supported → Smart Hub Platform entry
    if data == "profile:supported":
        await edit(t(lang, "supported_title"), __import__("bot.keyboards.common", fromlist=["supported_buttons"]).supported_buttons())
        await callback.answer()
        return
    if data == "supported:hub":
        from bot.keyboards.common import force_join_buttons
        await edit(t(lang, "force_join"), force_join_buttons())
        await callback.answer()
        return

    # Force-join check (3 channels/chats)
    if data == "forcejoin:check":
        # Soft check: we cannot always resolve public @ links without membership API
        # Try get_chat_member on known usernames when possible
        missing = []
        targets = [
            ("SmartArcade", "SmartArcade"),
            ("CodeDrop", "smarthub_codedrop"),
            ("Chat", "SmartArcade_chat"),
        ]
        for label, uname in targets:
            try:
                member = await client.get_chat_member(uname, uid)
                st = str(member.status).lower()
                if "left" in st or "banned" in st or "kicked" in st:
                    missing.append(label)
            except Exception:
                # If cannot verify, require user honesty — still allow but note
                pass
        if missing:
            await callback.answer(t(lang, "check_fail"), show_alert=True)
            return
        async with db.acquire() as conn:
            await conn.execute(
                "UPDATE users SET force_join_done = TRUE, updated_at = now() WHERE telegram_id = $1",
                uid,
            )
        await callback.answer(t(lang, "check_ok"), show_alert=True)
        from bot.keyboards.common import terms_buttons
        await edit(t(lang, "terms_title"), terms_buttons(lang))
        return

    # Terms
    if data == "terms:agree":
        async with db.acquire() as conn:
            await conn.execute(
                "UPDATE users SET rules_accepted = TRUE, is_verified = TRUE, updated_at = now() WHERE telegram_id = $1",
                uid,
            )
        from bot.keyboards.common import hub_platform_button
        await edit(t(lang, "agree_next"), hub_platform_button(lang))
        await callback.answer()
        return
    if data == "terms:disagree":
        try:
            await callback.message.delete()
        except Exception:
            pass
        await client.send_message(uid, t(lang, "disagree_bye"), parse_mode=enums.ParseMode.HTML)
        await callback.answer()
        return

    # Premium payment selection
    if data == "menu:premium":
        from bot.keyboards.common import payment_method_buttons
        from bot.config import get_settings as gs
        price = gs().plan_price
        await edit(t(lang, "premium_menu", price=price), payment_method_buttons(lang))
        await callback.answer()
        return
    if data in ("pay:wave", "pay:kpay"):
        method = "wave" if data.endswith("wave") else "kpay"
        phone = await db.get_setting("wave_phone" if method == "wave" else "kpay_phone", "")
        price = settings.plan_price
        if not phone:
            await edit(t(lang, "no_phone"))
            await callback.answer()
            return
        key = "pay_instr_wave" if method == "wave" else "pay_instr_kpay"
        await edit(t(lang, key, price=price, phone=phone))
        await callback.answer()
        return

    # Music / Group help text
    if data == "menu:music":
        await edit(t(lang, "music_help"))
        await callback.answer()
        return
    if data == "menu:grouphelp":
        await edit(t(lang, "grouphelp_help"))
        await callback.answer()
        return

    # Task Groups → assign A/B/C immediately
    if data == "menu:tasks":
        group = await db.next_task_group()
        await db.assign_task_group(uid, group)
        link = await db.get_setting(f"group_{group.lower()}_link") or "https://t.me/"
        await edit(t(lang, "task_assigned", group=group, link=link))
        await callback.answer()
        return

    if data == "menu:help":
        await edit(t(lang, "help_user"), help_modules())
        await callback.answer()
        return

    if data == "start:welcome":
        is_admin = settings.is_admin(uid)
        user = await db.get_user(uid)
        is_prem = bool(user and user.get("is_premium"))
        await edit(welcome_text(lang=lang), main_menu(is_prem, is_admin, lang))
        await callback.answer()
        return

    if data == "menu:admin":
        if not settings.is_admin(uid):
            await callback.answer(t(lang, "admin_only"), show_alert=True)
            return
        stats = await db.user_stats()
        await edit(admin_stats(stats) + "\n\n/setwave /setkpay /user /broadcast /check")
        await callback.answer()
        return

    await callback.answer()



async def cmd_broadcast(client: Client, message: Message) -> None:
    """Single unified broadcast for all modules."""
    settings = get_settings()
    if not settings.is_admin(message.from_user.id):
        return
    body = ""
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) > 1:
        body = parts[1].strip()
    if not body and message.reply_to_message:
        body = message.reply_to_message.text or message.reply_to_message.caption or ""
    if not body.strip() and not message.reply_to_message:
        await message.reply_text(
            "Usage:\n"
            "• Reply to a message then /broadcast\n"
            "• Or /broadcast your text\n\n"
            "Sends to all users in DB (one unified broadcast for all modules)."
        )
        return
    async with db.acquire() as conn:
        rows = await conn.fetch("SELECT telegram_id FROM users")
    sent = fail = 0
    status = await message.reply_text(f"Broadcasting to {len(rows)} users...")
    for r in rows:
        try:
            if message.reply_to_message and len(parts) <= 1:
                await message.reply_to_message.copy(r["telegram_id"])
            else:
                await client.send_message(r["telegram_id"], body)
            sent += 1
        except Exception:
            fail += 1
    await status.edit_text(f"Broadcast done.\nSent: {sent}\nFailed: {fail}\nTotal: {len(rows)}")
    await db.audit(message.from_user.id, "broadcast_all", metadata={"sent": sent, "fail": fail})



async def cmd_check(client: Client, message: Message) -> None:
    """Admin: /check <user_id> — has this user used the bot?"""
    settings = get_settings()
    lang = await user_lang(message.from_user.id)
    if not settings.is_admin(message.from_user.id):
        await message.reply_text(t(lang, "admin_only"), parse_mode=enums.ParseMode.HTML)
        return
    parts = (message.text or "").split()
    target = None
    if len(parts) >= 2 and parts[1].isdigit():
        target = int(parts[1])
    elif message.reply_to_message and message.reply_to_message.from_user:
        target = message.reply_to_message.from_user.id
    if not target:
        await message.reply_text("Usage: <code>/check userid</code>", parse_mode=enums.ParseMode.HTML)
        return
    user = await db.get_user(target)
    if not user:
        await message.reply_text(t(lang, "check_user_none", uid=target), parse_mode=enums.ParseMode.HTML)
        return
    rem = await db.remaining_hours(target)
    prem = "Yes" if user.get("is_premium") and rem > 0 else "No"
    seen = str(user.get("last_seen_at") or "—")
    await message.reply_text(
        t(lang, "check_user_found", uid=target, prem=prem, seen=seen),
        parse_mode=enums.ParseMode.HTML,
    )



def register_handlers(app: Client) -> None:
    # Core
    app.add_handler(MessageHandler(cmd_start, filters.command("start")))
    app.add_handler(MessageHandler(cmd_help, filters.command("help")))
    app.add_handler(MessageHandler(cmd_helpadminpanel, filters.command("helpadminpanel")))
    app.add_handler(MessageHandler(cmd_broadcast, filters.command("broadcast")))
    app.add_handler(MessageHandler(cmd_check, filters.command("check")))
    app.add_handler(MessageHandler(cmd_ping, filters.command("ping")))
    app.add_handler(CallbackQueryHandler(on_callback))

    # Premium
    app.add_handler(MessageHandler(premium.cmd_profile, filters.command("profile")))
    app.add_handler(MessageHandler(premium.cmd_premium_start, filters.command("premium")))
    app.add_handler(MessageHandler(premium.cmd_setwave, filters.command("setwave")))
    app.add_handler(MessageHandler(premium.cmd_setkpay, filters.command("setkpay")))
    app.add_handler(MessageHandler(premium.cmd_user_stats, filters.command("user")))
    app.add_handler(MessageHandler(premium.cmd_broadcast_premium, filters.command("broadcastpreuser")))
    app.add_handler(MessageHandler(premium.on_receipt_photo, filters.private & filters.photo))

    # Group Help moderation
    app.add_handler(MessageHandler(group_help.cmd_ban, filters.command("ban") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_unban, filters.command("unban") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_mute, filters.command("mute") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_unmute, filters.command("unmute") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_kick, filters.command("kick") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_warn, filters.command("warn") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_warns, filters.command("warns") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_rmwarn, filters.command("rmwarn") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_resetwarns, filters.command("resetwarns") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_pin, filters.command("pin") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_unpin, filters.command("unpin") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_del, filters.command("del") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_purge, filters.command("purge") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_setwelcome, filters.command("setwelcome") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_setrules, filters.command("setrules") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_rules, filters.command("rules") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_filter, filters.command("filter") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_stop_filter, filters.command("stop") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_filters, filters.command("filters") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_save_note, filters.command("save") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_get_note, filters.command("get") & filters.group))
    app.add_handler(MessageHandler(group_help.cmd_clear_note, filters.command("clear") & filters.group))
    app.add_handler(MessageHandler(group_help.on_group_message, filters.group & ~filters.service))

    # Task group
    app.add_handler(MessageHandler(task_group.cmd_setch, filters.command("setch")))
    app.add_handler(MessageHandler(task_group.cmd_setc, filters.command("setc")))
    app.add_handler(MessageHandler(lambda c, m: task_group.cmd_setgp(c, m, "A"), filters.command("setgp1")))
    app.add_handler(MessageHandler(lambda c, m: task_group.cmd_setgp(c, m, "B"), filters.command("setgp2")))
    app.add_handler(MessageHandler(lambda c, m: task_group.cmd_setgp(c, m, "C"), filters.command("setgp3")))
    app.add_handler(MessageHandler(task_group.cmd_setcheckgroup, filters.command("setcheckgroup")))
    app.add_handler(MessageHandler(task_group.cmd_setchecktopic, filters.command("setchecktopic")))
    app.add_handler(MessageHandler(task_group.cmd_do, filters.command("do") & filters.group))
    app.add_handler(MessageHandler(task_group.cmd_ndo, filters.command("ndo") & filters.group))
    app.add_handler(MessageHandler(task_group.on_task_photo, filters.group & filters.photo))

    # Music
    app.add_handler(MessageHandler(music.cmd_play, filters.command("play") & filters.group))
    app.add_handler(MessageHandler(music.cmd_vplay, filters.command("vplay") & filters.group))
    app.add_handler(MessageHandler(music.cmd_queue, filters.command(["queue", "q"]) & filters.group))
    app.add_handler(MessageHandler(music.cmd_pause, filters.command("pause") & filters.group))
    app.add_handler(MessageHandler(music.cmd_resume, filters.command("resume") & filters.group))
    app.add_handler(MessageHandler(music.cmd_skip, filters.command(["skip", "next"]) & filters.group))
    app.add_handler(MessageHandler(music.cmd_stop, filters.command(["stop", "end"]) & filters.group))
    app.add_handler(MessageHandler(music.cmd_volume, filters.command("volume") & filters.group))
    app.add_handler(MessageHandler(music.cmd_shuffle, filters.command("shuffle") & filters.group))
    app.add_handler(MessageHandler(music.cmd_loop, filters.command("loop") & filters.group))
    app.add_handler(MessageHandler(music.cmd_auth, filters.command("auth") & filters.group))
    app.add_handler(MessageHandler(music.cmd_unauth, filters.command("unauth") & filters.group))
    app.add_handler(MessageHandler(music.cmd_lyrics, filters.command("lyrics")))
    app.add_handler(MessageHandler(music.cmd_song, filters.command("song")))

    # Toggle helpers for group_help
    async def captcha_toggle(c, m):
        await group_help.cmd_toggle_flag(c, m, "captcha")
    async def antilink_toggle(c, m):
        await group_help.cmd_toggle_flag(c, m, "antilink")
    async def antichannel_toggle(c, m):
        await group_help.cmd_toggle_flag(c, m, "antichannel")
    app.add_handler(MessageHandler(captcha_toggle, filters.command("captcha") & filters.group))
    app.add_handler(MessageHandler(antilink_toggle, filters.command("antilink") & filters.group))
    app.add_handler(MessageHandler(antichannel_toggle, filters.command("antichannel") & filters.group))


async def premium_expiry_poller(worker_id: str = "main") -> None:
    settings = get_settings()
    while True:
        try:
            got = await db.acquire_lease("premium_expiry", worker_id, lease_seconds=settings.poll_interval_seconds + 30)
            if got:
                n = await db.expire_premiums()
                if n:
                    log.info("Expired %d premium users", n)
                await db.release_lease("premium_expiry", worker_id)
        except Exception:
            log.exception("premium expiry poller error")
        await asyncio.sleep(settings.poll_interval_seconds)


async def main() -> None:
    settings = get_settings()
    log.info("Starting Unified Bot (timezone=%s)", settings.timezone)
    await db.init_pool()
    app = create_app()
    register_handlers(app)

    # Background poller
    poller_task = asyncio.create_task(premium_expiry_poller())

    await app.start()
    me = await app.get_me()
    log.info("Bot online as @%s (%s)", me.username, me.id)

    # Real Voice Chat via Telegram USER account
    try:
        await vc.init_user_client()
        if vc.is_ready():
            log.info("Music VC engine ready (user account + PyTgCalls)")
        else:
            log.warning("Music VC engine NOT ready — set STRING_SESSION + API_ID/HASH + ffmpeg")
    except Exception as e:
        log.exception("VC init error: %s", e)

    # Graceful shutdown
    stop_event = asyncio.Event()

    def _signal_handler(*_):
        log.info("Shutdown signal received")
        stop_event.set()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            asyncio.get_event_loop().add_signal_handler(sig, _signal_handler)
        except NotImplementedError:
            pass

    try:
        await stop_event.wait()
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        poller_task.cancel()
        try:
            await vc.stop_user_client()
        except Exception:
            pass
        await app.stop()
        await db.close_pool()
        log.info("Shutdown complete")


if __name__ == "__main__":
    asyncio.run(main())
