"""Group Help & Management — moderation, filters, notes, anti-spam."""
from __future__ import annotations

import logging
import re
from datetime import datetime, timedelta, timezone
from typing import Optional

from pyrogram import Client, enums, filters
from pyrogram.types import ChatPermissions, Message

from bot.config import get_settings
from bot.database import db

log = logging.getLogger(__name__)

# Simple in-memory flood window (backed by DB for persistence if needed)
_flood_cache: dict = {}


def _parse_time(s: str) -> Optional[int]:
    """Parse 1h, 30m, 2d → seconds."""
    if not s:
        return None
    m = re.match(r"^(\d+)([smhd])?$", s.lower().strip())
    if not m:
        return None
    n, unit = int(m.group(1)), m.group(2) or "m"
    mult = {"s": 1, "m": 60, "h": 3600, "d": 86400}
    return n * mult.get(unit, 60)


async def _is_admin(client: Client, chat_id: int, user_id: int) -> bool:
    settings = get_settings()
    if settings.is_admin(user_id):
        return True
    try:
        member = await client.get_chat_member(chat_id, user_id)
        return member.status in (
            enums.ChatMemberStatus.ADMINISTRATOR,
            enums.ChatMemberStatus.OWNER,
        )
    except Exception:
        return False


async def _resolve_target(message: Message) -> Optional[int]:
    if message.reply_to_message and message.reply_to_message.from_user:
        return message.reply_to_message.from_user.id
    parts = (message.text or "").split(maxsplit=2)
    if len(parts) >= 2 and parts[1].isdigit():
        return int(parts[1])
    return None


# ------------------------------------------------------------------
# Moderation commands
# ------------------------------------------------------------------

async def cmd_ban(client: Client, message: Message) -> None:
    if message.chat.type not in ("group", "supergroup"):
        return
    if not await _is_admin(client, message.chat.id, message.from_user.id):
        return
    target = await _resolve_target(message)
    if not target:
        await message.reply_text("Reply to a user or provide user_id.")
        return
    reason = ""
    parts = (message.text or "").split(maxsplit=2)
    if len(parts) > 2:
        reason = parts[2]
    try:
        await client.ban_chat_member(message.chat.id, target)
        await message.reply_text(f"🚫 Banned `{target}`\nReason: {reason or '—'}")
        await db.audit(message.from_user.id, "ban", target, message.chat.id, {"reason": reason})
    except Exception as e:
        await message.reply_text(f"Failed: {e}")


async def cmd_unban(client: Client, message: Message) -> None:
    if message.chat.type not in ("group", "supergroup"):
        return
    if not await _is_admin(client, message.chat.id, message.from_user.id):
        return
    target = await _resolve_target(message)
    if not target:
        await message.reply_text("Reply to a user or provide user_id.")
        return
    try:
        await client.unban_chat_member(message.chat.id, target)
        await message.reply_text(f"✅ Unbanned `{target}`")
        await db.audit(message.from_user.id, "unban", target, message.chat.id)
    except Exception as e:
        await message.reply_text(f"Failed: {e}")


async def cmd_mute(client: Client, message: Message) -> None:
    if message.chat.type not in ("group", "supergroup"):
        return
    if not await _is_admin(client, message.chat.id, message.from_user.id):
        return
    target = await _resolve_target(message)
    if not target:
        await message.reply_text("Reply or provide user_id. Optional time: `/mute 1h`")
        return
    parts = (message.text or "").split()
    seconds = None
    for p in parts[1:]:
        seconds = _parse_time(p)
        if seconds:
            break
    until = datetime.now(timezone.utc) + timedelta(seconds=seconds) if seconds else None
    perms = ChatPermissions(can_send_messages=False)
    try:
        await client.restrict_chat_member(message.chat.id, target, perms, until_date=until)
        t = f" for {seconds}s" if seconds else ""
        await message.reply_text(f"🔇 Muted `{target}`{t}")
        await db.audit(message.from_user.id, "mute", target, message.chat.id, {"seconds": seconds})
    except Exception as e:
        await message.reply_text(f"Failed: {e}")


async def cmd_unmute(client: Client, message: Message) -> None:
    if message.chat.type not in ("group", "supergroup"):
        return
    if not await _is_admin(client, message.chat.id, message.from_user.id):
        return
    target = await _resolve_target(message)
    if not target:
        return
    perms = ChatPermissions(
        can_send_messages=True,
        can_send_media_messages=True,
        can_send_other_messages=True,
        can_add_web_page_previews=True,
    )
    try:
        await client.restrict_chat_member(message.chat.id, target, perms)
        await message.reply_text(f"🔊 Unmuted `{target}`")
        await db.audit(message.from_user.id, "unmute", target, message.chat.id)
    except Exception as e:
        await message.reply_text(f"Failed: {e}")


async def cmd_kick(client: Client, message: Message) -> None:
    if message.chat.type not in ("group", "supergroup"):
        return
    if not await _is_admin(client, message.chat.id, message.from_user.id):
        return
    target = await _resolve_target(message)
    if not target:
        return
    try:
        await client.ban_chat_member(message.chat.id, target)
        await client.unban_chat_member(message.chat.id, target)
        await message.reply_text(f"👢 Kicked `{target}`")
        await db.audit(message.from_user.id, "kick", target, message.chat.id)
    except Exception as e:
        await message.reply_text(f"Failed: {e}")


async def cmd_warn(client: Client, message: Message) -> None:
    if message.chat.type not in ("group", "supergroup"):
        return
    if not await _is_admin(client, message.chat.id, message.from_user.id):
        return
    target = await _resolve_target(message)
    if not target:
        return
    reason = ""
    parts = (message.text or "").split(maxsplit=2)
    if len(parts) > 2:
        reason = parts[2]
    async with db.acquire() as conn:
        await conn.execute(
            "INSERT INTO warnings (chat_id, telegram_id, admin_id, reason) VALUES ($1,$2,$3,$4)",
            message.chat.id, target, message.from_user.id, reason,
        )
        count = await conn.fetchval(
            "SELECT COUNT(*) FROM warnings WHERE chat_id = $1 AND telegram_id = $2",
            message.chat.id, target,
        )
        # get max_warns from chat_settings
        max_w = await conn.fetchval(
            "SELECT max_warns FROM chat_settings WHERE chat_id = $1", message.chat.id
        ) or 3
    await message.reply_text(f"⚠️ Warned `{target}` ({count}/{max_w})\nReason: {reason or '—'}")
    if count >= max_w:
        try:
            await client.ban_chat_member(message.chat.id, target)
            await message.reply_text(f"🚫 Auto-banned `{target}` (max warns reached)")
        except Exception:
            pass
    await db.audit(message.from_user.id, "warn", target, message.chat.id, {"reason": reason, "count": count})


async def cmd_warns(client: Client, message: Message) -> None:
    target = await _resolve_target(message) or message.from_user.id
    async with db.acquire() as conn:
        count = await conn.fetchval(
            "SELECT COUNT(*) FROM warnings WHERE chat_id = $1 AND telegram_id = $2",
            message.chat.id, target,
        )
    await message.reply_text(f"Warnings for `{target}`: **{count}**")


async def cmd_rmwarn(client: Client, message: Message) -> None:
    if not await _is_admin(client, message.chat.id, message.from_user.id):
        return
    target = await _resolve_target(message)
    if not target:
        return
    async with db.acquire() as conn:
        await conn.execute(
            """
            DELETE FROM warnings WHERE id = (
                SELECT id FROM warnings WHERE chat_id = $1 AND telegram_id = $2
                ORDER BY created_at DESC LIMIT 1
            )
            """,
            message.chat.id, target,
        )
    await message.reply_text(f"Removed one warning from `{target}`")


async def cmd_resetwarns(client: Client, message: Message) -> None:
    if not await _is_admin(client, message.chat.id, message.from_user.id):
        return
    target = await _resolve_target(message)
    if not target:
        return
    async with db.acquire() as conn:
        await conn.execute(
            "DELETE FROM warnings WHERE chat_id = $1 AND telegram_id = $2",
            message.chat.id, target,
        )
    await message.reply_text(f"Reset all warnings for `{target}`")


async def cmd_pin(client: Client, message: Message) -> None:
    if not await _is_admin(client, message.chat.id, message.from_user.id):
        return
    if not message.reply_to_message:
        await message.reply_text("Reply to the message you want to pin.")
        return
    try:
        await client.pin_chat_message(
            message.chat.id,
            message.reply_to_message.id,
            disable_notification=False,
        )
        await message.reply_text("📌 Pinned.")
    except Exception as e:
        await message.reply_text(f"Failed: {e}")


async def cmd_unpin(client: Client, message: Message) -> None:
    if not await _is_admin(client, message.chat.id, message.from_user.id):
        return
    try:
        await client.unpin_chat_message(message.chat.id)
        await message.reply_text("📍 Unpinned.")
    except Exception as e:
        await message.reply_text(f"Failed: {e}")


async def cmd_del(client: Client, message: Message) -> None:
    if not await _is_admin(client, message.chat.id, message.from_user.id):
        return
    if message.reply_to_message:
        try:
            await message.reply_to_message.delete()
            await message.delete()
        except Exception:
            pass


async def cmd_purge(client: Client, message: Message) -> None:
    if not await _is_admin(client, message.chat.id, message.from_user.id):
        return
    if not message.reply_to_message:
        await message.reply_text("Reply to the starting message.")
        return
    start_id = message.reply_to_message.id
    end_id = message.id
    deleted = 0
    for mid in range(start_id, end_id + 1):
        try:
            await client.delete_messages(message.chat.id, mid)
            deleted += 1
        except Exception:
            pass
    await message.reply_text(f"🗑 Purged ~{deleted} messages.")


# ------------------------------------------------------------------
# Settings
# ------------------------------------------------------------------

async def cmd_setwelcome(client: Client, message: Message) -> None:
    if not await _is_admin(client, message.chat.id, message.from_user.id):
        return
    text = None
    if message.reply_to_message:
        text = message.reply_to_message.text or message.reply_to_message.caption
    else:
        parts = (message.text or "").split(maxsplit=1)
        text = parts[1] if len(parts) > 1 else None
    if not text:
        await message.reply_text("Reply to a message or `/setwelcome text`")
        return
    async with db.acquire() as conn:
        await conn.execute(
            """
            INSERT INTO chat_settings (chat_id, welcome_text) VALUES ($1, $2)
            ON CONFLICT (chat_id) DO UPDATE SET welcome_text = $2, updated_at = now()
            """,
            message.chat.id, text,
        )
    await message.reply_text("✅ Welcome message saved.")


async def cmd_setrules(client: Client, message: Message) -> None:
    if not await _is_admin(client, message.chat.id, message.from_user.id):
        return
    text = None
    if message.reply_to_message:
        text = message.reply_to_message.text or message.reply_to_message.caption
    else:
        parts = (message.text or "").split(maxsplit=1)
        text = parts[1] if len(parts) > 1 else None
    if not text:
        await message.reply_text("Reply or `/setrules text`")
        return
    async with db.acquire() as conn:
        await conn.execute(
            """
            INSERT INTO chat_settings (chat_id, rules_text) VALUES ($1, $2)
            ON CONFLICT (chat_id) DO UPDATE SET rules_text = $2, updated_at = now()
            """,
            message.chat.id, text,
        )
    await message.reply_text("✅ Rules saved.")


async def cmd_rules(client: Client, message: Message) -> None:
    async with db.acquire() as conn:
        text = await conn.fetchval(
            "SELECT rules_text FROM chat_settings WHERE chat_id = $1", message.chat.id
        )
    if text:
        await message.reply_text(f"📜 **Rules**\n\n{text}")
    else:
        await message.reply_text("Rules မသတ်မှတ်ရသေးပါ။")


async def cmd_toggle_flag(client: Client, message: Message, flag: str) -> None:
    if not await _is_admin(client, message.chat.id, message.from_user.id):
        return
    parts = (message.text or "").split()
    val = None
    if len(parts) > 1:
        arg = parts[1].lower()
        if arg in ("on", "1", "true", "yes"):
            val = True
        elif arg in ("off", "0", "false", "no"):
            val = False
    if val is None:
        await message.reply_text(f"Usage: `/{flag} on|off`")
        return
    col = {"captcha": "captcha_on", "antilink": "antilink_on", "antichannel": "antichannel_on"}.get(flag)
    if not col:
        return
    async with db.acquire() as conn:
        await conn.execute(
            f"""
            INSERT INTO chat_settings (chat_id, {col}) VALUES ($1, $2)
            ON CONFLICT (chat_id) DO UPDATE SET {col} = $2, updated_at = now()
            """,
            message.chat.id, val,
        )
    await message.reply_text(f"✅ {flag} → {'ON' if val else 'OFF'}")


# ------------------------------------------------------------------
# Filters & Notes
# ------------------------------------------------------------------

async def cmd_filter(client: Client, message: Message) -> None:
    if not await _is_admin(client, message.chat.id, message.from_user.id):
        return
    parts = (message.text or "").split(maxsplit=2)
    if len(parts) < 3:
        await message.reply_text("Usage: `/filter trigger reply text`")
        return
    trigger, reply = parts[1].lower(), parts[2]
    async with db.acquire() as conn:
        await conn.execute(
            """
            INSERT INTO filters (chat_id, trigger, reply_text) VALUES ($1, $2, $3)
            ON CONFLICT (chat_id, trigger) DO UPDATE SET reply_text = $3
            """,
            message.chat.id, trigger, reply,
        )
    await message.reply_text(f"✅ Filter `{trigger}` saved.")


async def cmd_stop_filter(client: Client, message: Message) -> None:
    if not await _is_admin(client, message.chat.id, message.from_user.id):
        return
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        return
    trigger = parts[1].strip().lower()
    async with db.acquire() as conn:
        await conn.execute(
            "DELETE FROM filters WHERE chat_id = $1 AND trigger = $2",
            message.chat.id, trigger,
        )
    await message.reply_text(f"Removed filter `{trigger}`")


async def cmd_filters(client: Client, message: Message) -> None:
    async with db.acquire() as conn:
        rows = await conn.fetch(
            "SELECT trigger FROM filters WHERE chat_id = $1 ORDER BY trigger",
            message.chat.id,
        )
    if not rows:
        await message.reply_text("No filters.")
        return
    await message.reply_text("Active filters:\n" + "\n".join(f"• `{r['trigger']}`" for r in rows))


async def cmd_save_note(client: Client, message: Message) -> None:
    if not await _is_admin(client, message.chat.id, message.from_user.id):
        return
    parts = (message.text or "").split(maxsplit=2)
    if len(parts) < 3:
        await message.reply_text("Usage: `/save name content`")
        return
    name, content = parts[1].lower(), parts[2]
    async with db.acquire() as conn:
        await conn.execute(
            """
            INSERT INTO notes (chat_id, name, content) VALUES ($1, $2, $3)
            ON CONFLICT (chat_id, name) DO UPDATE SET content = $3
            """,
            message.chat.id, name, content,
        )
    await message.reply_text(f"✅ Note `#{name}` saved.")


async def cmd_get_note(client: Client, message: Message) -> None:
    parts = (message.text or "").split(maxsplit=1)
    name = parts[1].strip().lstrip("#").lower() if len(parts) > 1 else ""
    if not name:
        return
    async with db.acquire() as conn:
        content = await conn.fetchval(
            "SELECT content FROM notes WHERE chat_id = $1 AND name = $2",
            message.chat.id, name,
        )
    if content:
        await message.reply_text(content)
    else:
        await message.reply_text(f"Note `#{name}` not found.")


async def cmd_clear_note(client: Client, message: Message) -> None:
    if not await _is_admin(client, message.chat.id, message.from_user.id):
        return
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        return
    name = parts[1].strip().lstrip("#").lower()
    async with db.acquire() as conn:
        await conn.execute(
            "DELETE FROM notes WHERE chat_id = $1 AND name = $2",
            message.chat.id, name,
        )
    await message.reply_text(f"Cleared note `#{name}`")


# ------------------------------------------------------------------
# Anti-link / anti-channel (message watcher)
# ------------------------------------------------------------------

async def on_group_message(client: Client, message: Message) -> None:
    if message.chat.type not in ("group", "supergroup"):
        return
    if not message.from_user or message.from_user.is_bot:
        return
    # approved users skip
    async with db.acquire() as conn:
        approved = await conn.fetchval(
            "SELECT 1 FROM approved_users WHERE chat_id = $1 AND telegram_id = $2",
            message.chat.id, message.from_user.id,
        )
        settings = await conn.fetchrow(
            "SELECT antilink_on, antichannel_on FROM chat_settings WHERE chat_id = $1",
            message.chat.id,
        )
    if approved:
        return
    antilink = settings["antilink_on"] if settings else True
    antichannel = settings["antichannel_on"] if settings else True

    # anti-channel
    if antichannel and message.sender_chat and message.sender_chat.id != message.chat.id:
        try:
            await message.delete()
        except Exception:
            pass
        return

    # anti-link
    if antilink and message.text:
        if re.search(r"(t\.me/|telegram\.me/|https?://)", message.text, re.I):
            # allow admins
            if await _is_admin(client, message.chat.id, message.from_user.id):
                return
            try:
                await message.delete()
            except Exception:
                pass
            return

    # filters
    if message.text:
        text_lower = message.text.lower()
        async with db.acquire() as conn:
            rows = await conn.fetch(
                "SELECT trigger, reply_text FROM filters WHERE chat_id = $1",
                message.chat.id,
            )
        for r in rows:
            if r["trigger"] in text_lower or text_lower.startswith("#" + r["trigger"]):
                await message.reply_text(r["reply_text"])
                break
