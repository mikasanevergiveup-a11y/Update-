from bot.utils.i18n import t, user_lang
"""Music & Voice Chat — commands wired to real VC engine (user account + PyTgCalls)."""
from __future__ import annotations

import logging
import os
from pathlib import Path

from pyrogram import Client
from pyrogram.types import CallbackQuery, Message

from bot.config import get_settings
from bot.database import db
from bot.keyboards.common import music_controls
from bot.modules.music import vc
from bot.utils.messages import music_now_playing

log = logging.getLogger(__name__)
DOWNLOAD_DIR = Path("downloads")
DOWNLOAD_DIR.mkdir(exist_ok=True)


async def _is_music_admin(client: Client, chat_id: int, user_id: int) -> bool:
    settings = get_settings()
    if settings.is_admin(user_id):
        return True
    async with db.acquire() as conn:
        auth = await conn.fetchval(
            "SELECT 1 FROM music_auth WHERE chat_id = $1 AND telegram_id = $2",
            chat_id, user_id,
        )
    if auth:
        return True
    try:
        from pyrogram import enums
        member = await client.get_chat_member(chat_id, user_id)
        return member.status in (
            enums.ChatMemberStatus.ADMINISTRATOR,
            enums.ChatMemberStatus.OWNER,
        )
    except Exception:
        return False


async def cmd_play(client: Client, message: Message) -> None:
    if message.chat.type not in ("group", "supergroup"):
        await message.reply_text("Music works in **groups** with Voice Chat only.")
        return
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        await message.reply_text("Usage: `/play song name or youtube link`")
        return
    query = parts[1].strip()
    lang = await user_lang(message.from_user.id)
    status = await message.reply_text(t(lang, "searching"))

    if not vc.is_ready():
        await status.edit_text(t(lang, "vc_not_ready"))
        return

    result = await vc.play_or_enqueue(
        message.chat.id,
        query,
        message.from_user.id,
        message.from_user.first_name or "User",
        is_video=False,
    )
    if not result.get("ok"):
        err = result.get("error")
        if err == "not_found":
            await status.edit_text(t(lang, "not_found"))
        else:
            await status.edit_text(t(lang, "vc_fail"))
        return

    item = result["item"]
    if result.get("playing"):
        await status.edit_text(
            music_now_playing(item["title"], item.get("duration"), item["requester_name"]),
            reply_markup=music_controls(message.chat.id),
        )
    else:
        await status.edit_text(
            t(lang, "queued", title=item["title"], pos=result.get("position", "?"))
        )

    try:
        async with db.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO music_queues (chat_id, title, url, duration, requested_by, is_video, position)
                VALUES ($1,$2,$3,$4,$5,FALSE,$6)
                """,
                message.chat.id, item["title"], item.get("webpage_url"),
                item.get("duration"), item["requested_by"], result.get("position") or 0,
            )
    except Exception:
        pass


async def cmd_vplay(client: Client, message: Message) -> None:
    if message.chat.type not in ("group", "supergroup"):
        await message.reply_text("Video play works in groups only.")
        return
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        await message.reply_text("Usage: `/vplay video name or link`")
        return
    if not vc.is_ready():
        await message.reply_text("VC not ready — see /play help.")
        return
    status = await message.reply_text("Video search...")
    result = await vc.play_or_enqueue(
        message.chat.id,
        parts[1].strip(),
        message.from_user.id,
        message.from_user.first_name or "User",
        is_video=True,
    )
    if not result.get("ok"):
        await status.edit_text("Failed.")
        return
    item = result["item"]
    if result.get("playing"):
        await status.edit_text(
            f"**Now Playing (video)**\n\n**{item['title']}**",
            reply_markup=music_controls(message.chat.id),
        )
    else:
        await status.edit_text(f"Queued video: **{item['title']}**")


async def cmd_queue(client: Client, message: Message) -> None:
    chat_id = message.chat.id
    cur = vc.get_current().get(chat_id)
    q = vc.get_queues().get(chat_id) or []
    lines = []
    if cur:
        lines.append(f"Now: {cur['title']}")
    for i, item in enumerate(q, 1):
        lines.append(f"{i}. {item['title']}")
    if not lines:
        await message.reply_text("Queue is empty.")
        return
    await message.reply_text("**Queue**\n\n" + "\n".join(lines))


async def cmd_pause(client: Client, message: Message) -> None:
    if not await _is_music_admin(client, message.chat.id, message.from_user.id):
        return
    ok = await vc.pause(message.chat.id)
    await message.reply_text("Paused." if ok else "Nothing playing / failed.")


async def cmd_resume(client: Client, message: Message) -> None:
    if not await _is_music_admin(client, message.chat.id, message.from_user.id):
        return
    ok = await vc.resume(message.chat.id)
    await message.reply_text("Resumed." if ok else "Nothing paused / failed.")


async def cmd_skip(client: Client, message: Message) -> None:
    if not await _is_music_admin(client, message.chat.id, message.from_user.id):
        return
    nxt = await vc.skip(message.chat.id)
    if nxt:
        await message.reply_text(
            music_now_playing(nxt["title"], nxt.get("duration"), nxt.get("requester_name", "-")),
            reply_markup=music_controls(message.chat.id),
        )
    else:
        await message.reply_text("Queue empty — left VC.")


async def cmd_stop(client: Client, message: Message) -> None:
    if not await _is_music_admin(client, message.chat.id, message.from_user.id):
        return
    await vc.leave(message.chat.id)
    try:
        async with db.acquire() as conn:
            await conn.execute("DELETE FROM music_queues WHERE chat_id = $1", message.chat.id)
    except Exception:
        pass
    await message.reply_text("Stopped & left Voice Chat.")


async def cmd_volume(client: Client, message: Message) -> None:
    if not await _is_music_admin(client, message.chat.id, message.from_user.id):
        return
    parts = (message.text or "").split()
    if len(parts) < 2 or not parts[1].isdigit():
        await message.reply_text("Usage: `/volume 1-200`")
        return
    vol = int(parts[1])
    ok = await vc.set_volume(message.chat.id, vol)
    await message.reply_text(f"Volume {max(1, min(200, vol))}%" + ("" if ok else " (saved)"))


async def cmd_shuffle(client: Client, message: Message) -> None:
    if not await _is_music_admin(client, message.chat.id, message.from_user.id):
        return
    import random
    q = vc.get_queues().get(message.chat.id)
    if q:
        random.shuffle(q)
        await message.reply_text("Queue shuffled.")
    else:
        await message.reply_text("Queue empty.")


async def cmd_loop(client: Client, message: Message) -> None:
    if not await _is_music_admin(client, message.chat.id, message.from_user.id):
        return
    flags = vc.get_loop()
    chat_id = message.chat.id
    flags[chat_id] = not flags.get(chat_id, False)
    await message.reply_text(f"Loop {'ON' if flags[chat_id] else 'OFF'}")


async def cmd_auth(client: Client, message: Message) -> None:
    if not await _is_music_admin(client, message.chat.id, message.from_user.id):
        return
    target = None
    if message.reply_to_message and message.reply_to_message.from_user:
        target = message.reply_to_message.from_user.id
    else:
        parts = (message.text or "").split()
        if len(parts) > 1 and parts[1].isdigit():
            target = int(parts[1])
    if not target:
        await message.reply_text("Reply or provide user_id.")
        return
    async with db.acquire() as conn:
        await conn.execute(
            """
            INSERT INTO music_auth (chat_id, telegram_id, granted_by)
            VALUES ($1, $2, $3) ON CONFLICT DO NOTHING
            """,
            message.chat.id, target, message.from_user.id,
        )
    await message.reply_text(f"Authorized `{target}` for music controls.")


async def cmd_unauth(client: Client, message: Message) -> None:
    if not await _is_music_admin(client, message.chat.id, message.from_user.id):
        return
    target = None
    if message.reply_to_message and message.reply_to_message.from_user:
        target = message.reply_to_message.from_user.id
    else:
        parts = (message.text or "").split()
        if len(parts) > 1 and parts[1].isdigit():
            target = int(parts[1])
    if not target:
        return
    async with db.acquire() as conn:
        await conn.execute(
            "DELETE FROM music_auth WHERE chat_id = $1 AND telegram_id = $2",
            message.chat.id, target,
        )
    await message.reply_text(f"Revoked music auth for `{target}`")


async def cmd_lyrics(client: Client, message: Message) -> None:
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        await message.reply_text("Usage: `/lyrics song name`")
        return
    await message.reply_text(f"Lyrics search: **{parts[1]}**")


async def cmd_song(client: Client, message: Message) -> None:
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        await message.reply_text("Usage: `/song name or link`")
        return
    status = await message.reply_text("Downloading...")
    info = await vc._resolve_stream(parts[1], is_video=False)
    if not info:
        await status.edit_text("Not found.")
        return
    try:
        import yt_dlp
        import asyncio
        out_stem = f"{message.from_user.id}_{message.id}"
        outtmpl = str(DOWNLOAD_DIR / f"{out_stem}.%(ext)s")
        opts = {
            "format": "bestaudio/best",
            "outtmpl": outtmpl,
            "quiet": True,
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "192",
            }],
        }
        loop = asyncio.get_event_loop()

        def dl():
            with yt_dlp.YoutubeDL(opts) as ydl:
                meta = ydl.extract_info(info["webpage_url"], download=True)
                base = ydl.prepare_filename(meta).rsplit(".", 1)[0]
                return base + ".mp3"

        path = await loop.run_in_executor(None, dl)
        if not path or not os.path.exists(path):
            await status.edit_text("Download failed (need ffmpeg).")
            return
        await message.reply_audio(path, title=info["title"], caption=f"{info['title']}")
        await status.delete()
        try:
            os.remove(path)
        except Exception:
            pass
    except Exception as e:
        await status.edit_text(f"Failed: {e}")


async def on_music_callback(client: Client, callback: CallbackQuery) -> None:
    data = callback.data or ""
    if not data.startswith("music:"):
        return
    parts = data.split(":")
    if len(parts) < 3:
        return
    action, chat_id_s = parts[1], parts[2]
    try:
        chat_id = int(chat_id_s)
    except ValueError:
        return
    if not await _is_music_admin(client, chat_id, callback.from_user.id):
        await callback.answer("Not authorized", show_alert=True)
        return

    if action == "pause":
        await vc.pause(chat_id)
        await callback.answer("Paused")
    elif action == "resume":
        await vc.resume(chat_id)
        await callback.answer("Resumed")
    elif action == "skip":
        nxt = await vc.skip(chat_id)
        if nxt:
            await callback.message.edit_text(
                music_now_playing(nxt["title"], nxt.get("duration"), nxt.get("requester_name", "-")),
                reply_markup=music_controls(chat_id),
            )
        else:
            await callback.message.edit_text("Queue empty — left VC.")
        await callback.answer()
    elif action == "stop":
        await vc.leave(chat_id)
        await callback.message.edit_text("Stopped.")
        await callback.answer()
    elif action == "mute":
        await vc.set_volume(chat_id, 0)
        await callback.answer("Muted")
    elif action == "unmute":
        await vc.set_volume(chat_id, 100)
        await callback.answer("Unmuted")
    elif action == "shuffle":
        import random
        q = vc.get_queues().get(chat_id)
        if q:
            random.shuffle(q)
        await callback.answer("Shuffled")
    elif action == "loop":
        flags = vc.get_loop()
        flags[chat_id] = not flags.get(chat_id, False)
        await callback.answer(f"Loop {'ON' if flags[chat_id] else 'OFF'}")
    elif action == "queue":
        cur = vc.get_current().get(chat_id)
        q = vc.get_queues().get(chat_id) or []
        lines = []
        if cur:
            lines.append(f"Now: {cur['title']}")
        for i, item in enumerate(q, 1):
            lines.append(f"{i}. {item['title']}")
        await callback.answer()
        await callback.message.reply_text("Queue\n" + ("\n".join(lines) or "Empty"))
    else:
        await callback.answer(action)
