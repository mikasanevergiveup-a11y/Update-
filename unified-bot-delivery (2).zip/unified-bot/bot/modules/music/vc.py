"""
Voice Chat engine — Telegram USER account + PyTgCalls.

Requires:
  - API_ID, API_HASH
  - STRING_SESSION or a one-time login that creates session file SESSION_NAME_user
  - ffmpeg installed on the VPS
  - User account must be a member of the group (and able to join VC)
"""
from __future__ import annotations

import asyncio
import logging
import os
from pathlib import Path
from typing import Dict, Optional

log = logging.getLogger(__name__)

# Lazy imports so bot can start even if pytgcalls not installed yet
_user_client = None
_call_client = None
_active: Dict[int, dict] = {}  # chat_id -> {title, ...}
_paused: Dict[int, bool] = {}
_loop_flag: Dict[int, bool] = {}
_queues: Dict[int, list] = {}
_volume: Dict[int, int] = {}

DOWNLOAD_DIR = Path("downloads")
DOWNLOAD_DIR.mkdir(exist_ok=True)


def get_queues() -> Dict[int, list]:
    return _queues


def get_current() -> Dict[int, dict]:
    return _active


def get_paused() -> Dict[int, bool]:
    return _paused


def get_loop() -> Dict[int, bool]:
    return _loop_flag


async def init_user_client():
    """Start Pyrogram USER client + PyTgCalls. Call once from main()."""
    global _user_client, _call_client
    if _user_client is not None:
        return _user_client

    from bot.config import get_settings
    settings = get_settings()

    if not settings.api_id or not settings.api_hash:
        log.warning("API_ID/API_HASH missing — VC streaming disabled")
        return None

    from pyrogram import Client

    session = os.getenv("USER_SESSION_NAME", f"{settings.session_name}_user")
    string_session = (getattr(settings, "string_session", None) or os.getenv("STRING_SESSION", "")).strip() or None

    kwargs = dict(
        name=session,
        api_id=settings.api_id,
        api_hash=settings.api_hash,
        workdir=str(Path(__file__).resolve().parents[2]),
        in_memory=False,
    )
    if string_session:
        kwargs["session_string"] = string_session

    _user_client = Client(**kwargs)
    await _user_client.start()
    me = await _user_client.get_me()
    log.info("VC user account online: %s (%s)", me.first_name, me.id)

    try:
        from pytgcalls import PyTgCalls
        from pytgcalls.types import Update

        _call_client = PyTgCalls(_user_client)
        await _call_client.start()
        log.info("PyTgCalls started")

        @_call_client.on_stream_end()
        async def _on_stream_end(_, update: Update):
            chat_id = update.chat_id
            log.info("Stream ended in %s", chat_id)
            await play_next(chat_id)

    except Exception as e:
        log.exception("PyTgCalls init failed (install pytgcalls + ffmpeg): %s", e)
        _call_client = None

    return _user_client


async def stop_user_client():
    global _user_client, _call_client
    try:
        if _call_client:
            # leave all
            for cid in list(_active.keys()):
                try:
                    await leave(cid)
                except Exception:
                    pass
        if _user_client:
            await _user_client.stop()
    except Exception:
        log.exception("Error stopping VC client")
    _user_client = None
    _call_client = None


async def _resolve_stream(url_or_query: str, is_video: bool = False) -> Optional[dict]:
    """yt-dlp → streamable URL + metadata."""
    try:
        import yt_dlp
    except ImportError:
        log.error("yt-dlp not installed")
        return None

    fmt = "best[height<=720]/best" if is_video else "bestaudio/best"
    ydl_opts = {
        "format": fmt,
        "quiet": True,
        "no_warnings": True,
        "default_search": "ytsearch1",
        "noplaylist": True,
        "extract_flat": False,
    }
    loop = asyncio.get_event_loop()

    def extract():
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url_or_query, download=False)
            if "entries" in info:
                info = info["entries"][0]
            return {
                "title": info.get("title") or "Unknown",
                "stream_url": info.get("url"),
                "webpage_url": info.get("webpage_url") or url_or_query,
                "duration": info.get("duration"),
                "is_video": is_video,
            }

    try:
        return await loop.run_in_executor(None, extract)
    except Exception as e:
        log.exception("yt-dlp failed: %s", e)
        return None


async def enqueue(chat_id: int, item: dict) -> int:
    q = _queues.setdefault(chat_id, [])
    q.append(item)
    return len(q)


async def play_or_enqueue(chat_id: int, query: str, requester_id: int, requester_name: str, is_video: bool = False) -> dict:
    """Resolve track, enqueue, start if nothing playing. Returns status dict."""
    info = await _resolve_stream(query, is_video=is_video)
    if not info or not info.get("stream_url"):
        return {"ok": False, "error": "not_found"}

    item = {
        "title": info["title"],
        "stream_url": info["stream_url"],
        "webpage_url": info["webpage_url"],
        "duration": info.get("duration"),
        "requested_by": requester_id,
        "requester_name": requester_name,
        "is_video": is_video,
    }
    pos = await enqueue(chat_id, item)

    if chat_id not in _active:
        ok = await start_stream(chat_id, item)
        if not ok:
            return {"ok": False, "error": "vc_failed", "item": item}
        return {"ok": True, "playing": True, "item": item}

    return {"ok": True, "playing": False, "position": pos, "item": item}


async def start_stream(chat_id: int, item: dict) -> bool:
    """Join VC (if needed) and play stream_url via user account."""
    if _call_client is None or _user_client is None:
        log.error("VC client not initialized")
        return False

    try:
        from pytgcalls.types.input_stream import AudioPiped, AudioVideoPiped
        from pytgcalls.types.input_stream.quality import HighQualityAudio, MediumQualityVideo

        stream_url = item["stream_url"]
        if item.get("is_video"):
            stream = AudioVideoPiped(
                stream_url,
                audio_parameters=HighQualityAudio(),
                video_parameters=MediumQualityVideo(),
            )
        else:
            stream = AudioPiped(stream_url, HighQualityAudio())

        # Join or change stream
        try:
            await _call_client.join_group_call(chat_id, stream)
        except Exception:
            # already in call → change stream
            try:
                await _call_client.change_stream(chat_id, stream)
            except Exception as e2:
                log.exception("join/change_stream failed: %s", e2)
                return False

        _active[chat_id] = item
        _paused[chat_id] = False
        # remove from front of queue if it is the same item we just started
        q = _queues.get(chat_id) or []
        if q and q[0] is item:
            q.pop(0)
        log.info("Playing in %s: %s", chat_id, item["title"])
        return True
    except Exception as e:
        log.exception("start_stream error: %s", e)
        return False


async def play_next(chat_id: int) -> Optional[dict]:
    if _loop_flag.get(chat_id) and chat_id in _active:
        # replay current
        item = _active[chat_id]
        # re-resolve stream URL (may expire)
        fresh = await _resolve_stream(item.get("webpage_url") or item["stream_url"], item.get("is_video", False))
        if fresh and fresh.get("stream_url"):
            item["stream_url"] = fresh["stream_url"]
        await start_stream(chat_id, item)
        return item

    q = _queues.get(chat_id) or []
    if not q:
        await leave(chat_id)
        return None
    item = q.pop(0)
    # refresh stream url
    fresh = await _resolve_stream(item.get("webpage_url") or item["stream_url"], item.get("is_video", False))
    if fresh and fresh.get("stream_url"):
        item["stream_url"] = fresh["stream_url"]
        item["title"] = fresh.get("title") or item["title"]
    ok = await start_stream(chat_id, item)
    return item if ok else None


async def pause(chat_id: int) -> bool:
    if not _call_client or chat_id not in _active:
        return False
    try:
        await _call_client.pause_stream(chat_id)
        _paused[chat_id] = True
        return True
    except Exception as e:
        log.exception("pause: %s", e)
        return False


async def resume(chat_id: int) -> bool:
    if not _call_client or chat_id not in _active:
        return False
    try:
        await _call_client.resume_stream(chat_id)
        _paused[chat_id] = False
        return True
    except Exception as e:
        log.exception("resume: %s", e)
        return False


async def skip(chat_id: int) -> Optional[dict]:
    return await play_next(chat_id)


async def leave(chat_id: int) -> None:
    _queues[chat_id] = []
    _active.pop(chat_id, None)
    _paused.pop(chat_id, None)
    if _call_client:
        try:
            await _call_client.leave_group_call(chat_id)
        except Exception:
            pass


async def set_volume(chat_id: int, vol: int) -> bool:
    vol = max(1, min(200, vol))
    _volume[chat_id] = vol
    if not _call_client or chat_id not in _active:
        return False
    try:
        await _call_client.change_volume_call(chat_id, vol)
        return True
    except Exception as e:
        log.exception("volume: %s", e)
        return False


def is_ready() -> bool:
    return _user_client is not None and _call_client is not None
