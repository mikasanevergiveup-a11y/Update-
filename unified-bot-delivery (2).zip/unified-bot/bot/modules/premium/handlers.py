"""Premium membership & payment receipt handlers."""
from __future__ import annotations

import logging
from typing import Optional

from pyrogram import Client, filters
from pyrogram.types import CallbackQuery, Message

from bot.config import get_settings
from bot.database import db
from bot.keyboards.common import profile_buttons, receipt_admin_buttons
from bot.utils.i18n import t, user_lang
from bot.utils.messages import (
    admin_stats,
    confirm_user_msg,
    pending_already,
    premium_start,
    profile_card,
    receipt_ack,
    reject_user_msg,
)

log = logging.getLogger(__name__)


def register(app: Client) -> None:
    app.add_handler(
        app.constructor if False else  # noqa — keep type checkers happy
        None
    )  # placeholder, real registration below


# Real registration done via decorators on the shared Client instance
# We export functions that the main module will attach.


async def cmd_profile(client: Client, message: Message) -> None:
    from pyrogram import enums
    lang = await user_lang(message.from_user.id)
    user = await db.upsert_user(
        message.from_user.id,
        message.from_user.username,
        message.from_user.first_name,
        message.from_user.last_name,
        message.from_user.language_code,
    )
    remaining = await db.remaining_hours(message.from_user.id)
    text = profile_card(user, remaining, lang)
    await message.reply_text(
        text, reply_markup=profile_buttons(lang),
        disable_web_page_preview=True, parse_mode=enums.ParseMode.HTML,
    )


async def cmd_premium_start(client: Client, message: Message) -> None:
    from bot.keyboards.common import payment_method_buttons
    from pyrogram import enums
    lang = await user_lang(message.from_user.id)
    settings = get_settings()
    await message.reply_text(
        premium_start(price=settings.plan_price, lang=lang),
        reply_markup=payment_method_buttons(lang),
        disable_web_page_preview=True,
        parse_mode=enums.ParseMode.HTML,
    )


async def on_receipt_photo(client: Client, message: Message) -> None:
    """User sends a photo in private → treat as payment receipt."""
    if message.chat.type != "private":
        return
    if not message.photo:
        return
    settings = get_settings()
    user = await db.upsert_user(
        message.from_user.id,
        message.from_user.username,
        message.from_user.first_name,
        message.from_user.last_name,
        message.from_user.language_code,
    )
    existing = await db.get_pending_receipt(user["telegram_id"])
    if existing:
        await message.reply_text(pending_already())
        return

    photo = message.photo
    # largest size is last
    file_id = photo.file_id
    unique_id = getattr(photo, "file_unique_id", None)

    receipt = await db.create_receipt(
        user["telegram_id"],
        file_id,
        unique_id,
        settings.premium_default_hours,
    )
    if not receipt:
        await message.reply_text(pending_already())
        return

    admin_group = settings.admin_group_id or await db.get_setting("admin_group_id")
    if not admin_group:
        await message.reply_text("Admin group မသတ်မှတ်ရသေးပါ။ Admin ကို ဆက်သွယ်ပါ။")
        return

    caption = (
        f"💳 **New Premium Receipt**\n\n"
        f"User: `{user['telegram_id']}`\n"
        f"Name: {user.get('full_name') or '—'}\n"
        f"Username: @{user.get('username') or '—'}\n"
        f"Receipt ID: `{receipt['id']}`"
    )
    try:
        sent = await client.send_photo(
            chat_id=int(admin_group),
            photo=file_id,
            caption=caption,
            reply_markup=receipt_admin_buttons(receipt["id"]),
        )
        await db.audit(
            message.from_user.id,
            "receipt_submitted",
            target_id=user["telegram_id"],
            metadata={"receipt_id": receipt["id"]},
        )
    except Exception as e:
        log.exception("Failed to forward receipt to admin group: %s", e)
        await message.reply_text("ပြေစာ ပို့ရာတွင် အမှားရှိပါသည်။ နောက်မှ ထပ်ကြိုးစားပါ။")
        return

    await message.reply_text(receipt_ack())


async def on_receipt_callback(client: Client, callback: CallbackQuery) -> None:
    data = callback.data or ""
    if not data.startswith("receipt:"):
        return
    parts = data.split(":")
    if len(parts) != 3:
        await callback.answer("Invalid action", show_alert=True)
        return
    action, receipt_id_s = parts[1], parts[2]
    try:
        receipt_id = int(receipt_id_s)
    except ValueError:
        await callback.answer("Invalid ID", show_alert=True)
        return

    settings = get_settings()
    if not settings.is_admin(callback.from_user.id):
        # also allow if message is in admin group
        admin_group = settings.admin_group_id or await db.get_setting("admin_group_id")
        if not admin_group or str(callback.message.chat.id) not in (
            str(admin_group),
            f"-100{str(admin_group).lstrip('-')}",
        ):
            await callback.answer("Admin only", show_alert=True)
            return

    if action == "confirm":
        user_row = await db.confirm_receipt(
            receipt_id,
            callback.from_user.id,
            callback.message.chat.id,
            callback.message.id,
        )
        if not user_row:
            await callback.answer("Already processed or not found", show_alert=True)
            return
        hours = settings.premium_default_hours
        await callback.message.edit_caption(
            callback.message.caption + f"\n\n✅ Confirmed by {callback.from_user.first_name}",
            reply_markup=None,
        )
        try:
            await client.send_message(user_row["telegram_id"], confirm_user_msg(hours))
        except Exception:
            pass
        await db.audit(
            callback.from_user.id,
            "receipt_confirmed",
            target_id=user_row["telegram_id"],
            metadata={"receipt_id": receipt_id},
        )
        await callback.answer("Confirmed ✅")
    elif action == "reject":
        ok = await db.reject_receipt(
            receipt_id,
            callback.from_user.id,
            callback.message.chat.id,
            callback.message.id,
        )
        if not ok:
            await callback.answer("Already processed or not found", show_alert=True)
            return
        # fetch telegram_id for notify
        async with db.acquire() as conn:
            tid = await conn.fetchval(
                "SELECT telegram_id FROM premium_receipts WHERE id = $1", receipt_id
            )
        await callback.message.edit_caption(
            callback.message.caption + f"\n\n❌ Rejected by {callback.from_user.first_name}",
            reply_markup=None,
        )
        if tid:
            try:
                await client.send_message(tid, reject_user_msg())
            except Exception:
                pass
        await db.audit(
            callback.from_user.id,
            "receipt_rejected",
            target_id=tid,
            metadata={"receipt_id": receipt_id},
        )
        await callback.answer("Rejected ❌")


async def cmd_setwave(client: Client, message: Message) -> None:
    settings = get_settings()
    if not settings.is_admin(message.from_user.id):
        return
    parts = (message.text or "").split(maxsplit=1)
    phone = parts[1].strip() if len(parts) > 1 else ""
    if not phone and message.reply_to_message:
        phone = (message.reply_to_message.text or "").strip()
    if not phone:
        await message.reply_text("အသုံးပြုပုံ — `/setwave 09xxxxxxxxx`")
        return
    await db.set_setting("wave_phone", phone)
    await message.reply_text(f"Wave နံပါတ် သိမ်းပြီး — `{phone}`")


async def cmd_setkpay(client: Client, message: Message) -> None:
    settings = get_settings()
    if not settings.is_admin(message.from_user.id):
        return
    parts = (message.text or "").split(maxsplit=1)
    phone = parts[1].strip() if len(parts) > 1 else ""
    if not phone and message.reply_to_message:
        phone = (message.reply_to_message.text or "").strip()
    if not phone:
        await message.reply_text("အသုံးပြုပုံ — `/setkpay 09xxxxxxxxx`")
        return
    await db.set_setting("kpay_phone", phone)
    await message.reply_text(f"KPay နံပါတ် သိမ်းပြီး — `{phone}`")


async def cmd_user_stats(client: Client, message: Message) -> None:
    settings = get_settings()
    if not settings.is_admin(message.from_user.id):
        return
    stats = await db.user_stats()
    await message.reply_text(admin_stats(stats))


async def cmd_broadcast_premium(client: Client, message: Message) -> None:
    settings = get_settings()
    if not settings.is_admin(message.from_user.id):
        return
    parts = (message.text or "").split(maxsplit=1)
    body = parts[1].strip() if len(parts) > 1 else ""
    if not body and message.reply_to_message:
        body = message.reply_to_message.text or message.reply_to_message.caption or ""
    if not body.strip():
        await message.reply_text(
            "အသုံးပြုပုံ — `/broadcastpreuser စာ`\nPremium user များကိုသာ ပို့ပါမယ်။"
        )
        return
    async with db.acquire() as conn:
        rows = await conn.fetch(
            "SELECT telegram_id FROM users WHERE is_premium = TRUE AND premium_until > now()"
        )
    sent = fail = 0
    for r in rows:
        try:
            await client.send_message(r["telegram_id"], body)
            sent += 1
        except Exception:
            fail += 1
    await message.reply_text(
        f"Broadcast ပြီးပါပြီ။\nရောက် — {sent}\nမရောက် — {fail}\nပို့သူ — {len(rows)} (active premium)"
    )
    await db.audit(message.from_user.id, "broadcast_premium", metadata={"sent": sent, "fail": fail})
