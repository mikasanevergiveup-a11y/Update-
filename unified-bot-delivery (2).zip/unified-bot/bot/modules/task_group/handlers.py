"""Task Group assignment, force-join, rules, photo review (ported from Group Task bot)."""
from __future__ import annotations

import logging
from datetime import date

from pyrogram import Client
from pyrogram.types import CallbackQuery, Message

from bot.config import get_settings
from bot.database import db
from bot.keyboards.common import force_join_buttons, rules_buttons, task_review_buttons
from bot.utils.messages import force_join_text

log = logging.getLogger(__name__)


async def ensure_force_join(client: Client, message: Message) -> bool:
    user = await db.get_user(message.from_user.id)
    if user and user.get("force_join_done"):
        return True
    channel_id = await db.get_setting("channel_chat_id")
    chat_id = await db.get_setting("chat_chat_id")
    channel_link = await db.get_setting("channel_link") or "https://t.me/"
    chat_link = await db.get_setting("chat_link") or "https://t.me/"
    if not channel_id and not chat_id:
        return True
    await message.reply_text(
        force_join_text(),
        reply_markup=force_join_buttons(channel_link, chat_link),
    )
    return False


async def on_forcejoin_check(client: Client, callback: CallbackQuery) -> None:
    if callback.data != "forcejoin:check":
        return
    channel_id = await db.get_setting("channel_chat_id")
    chat_id_s = await db.get_setting("chat_chat_id")
    missing = []
    for label, cid in (("Channel", channel_id), ("Chat", chat_id_s)):
        if not cid:
            continue
        try:
            member = await client.get_chat_member(
                int(cid) if str(cid).lstrip("-").isdigit() else cid,
                callback.from_user.id,
            )
            status = str(member.status).lower()
            if "left" in status or "banned" in status or "kicked" in status:
                missing.append(label)
        except Exception:
            missing.append(label)
    if missing:
        await callback.answer(f"Please join: {', '.join(missing)}", show_alert=True)
        return
    async with db.acquire() as conn:
        await conn.execute(
            "UPDATE users SET force_join_done = TRUE, updated_at = now() WHERE telegram_id = $1",
            callback.from_user.id,
        )
    await callback.answer("Verified!")
    await callback.message.edit_text("Force-join complete. Use /start again.")


async def cmd_setch(client: Client, message: Message) -> None:
    settings = get_settings()
    if not settings.is_admin(message.from_user.id):
        return
    parts = (message.text or "").split(maxsplit=2)
    if len(parts) < 3:
        await message.reply_text("Usage: /setch <chat_id_or_username> <invite_link>")
        return
    await db.set_setting("channel_chat_id", parts[1])
    await db.set_setting("channel_link", parts[2])
    await message.reply_text(f"Channel set: `{parts[1]}`")


async def cmd_setc(client: Client, message: Message) -> None:
    settings = get_settings()
    if not settings.is_admin(message.from_user.id):
        return
    parts = (message.text or "").split(maxsplit=2)
    if len(parts) < 3:
        await message.reply_text("Usage: /setc <chat_id_or_username> <invite_link>")
        return
    await db.set_setting("chat_chat_id", parts[1])
    await db.set_setting("chat_link", parts[2])
    await message.reply_text(f"Chat set: `{parts[1]}`")


async def cmd_setgp(client: Client, message: Message, label: str) -> None:
    settings = get_settings()
    if not settings.is_admin(message.from_user.id):
        return
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        await message.reply_text(f"Usage: /setgp{label.lower()} <invite_link>")
        return
    await db.set_setting(f"group_{label.lower()}_link", parts[1])
    await message.reply_text(f"Task Group {label} link saved.")


async def cmd_setcheckgroup(client: Client, message: Message) -> None:
    settings = get_settings()
    if not settings.is_admin(message.from_user.id):
        return
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        await message.reply_text("Usage: /setcheckgroup <chat_id>")
        return
    await db.set_setting("checking_group_chat_id", parts[1])
    await message.reply_text(f"Checker group set: `{parts[1]}`")


async def cmd_setchecktopic(client: Client, message: Message) -> None:
    settings = get_settings()
    if not settings.is_admin(message.from_user.id):
        return
    parts = (message.text or "").split(maxsplit=2)
    if len(parts) < 3:
        await message.reply_text("Usage: /setchecktopic A|B|C <topic_link_or_id>")
        return
    label = parts[1].upper()
    if label not in ("A", "B", "C"):
        await message.reply_text("Label must be A, B or C")
        return
    await db.set_setting(f"checking_topic_{label}", parts[2])
    await message.reply_text(f"Checker topic {label} saved.")


async def start_task_onboarding(client: Client, message: Message) -> None:
    group = await db.next_task_group()
    await db.assign_task_group(message.from_user.id, group)
    link = await db.get_setting(f"group_{group.lower()}_link") or "https://t.me/"
    await message.reply_text(
        f"You are assigned to **Task Group {group}**\n\n"
        f"Join here: {link}\n\n"
        "Photo တင်ပြီး Checker မှ အတည်ပြုမှသာ task ပြီးမြောက်ပါမည်။"
    )


async def on_rules_callback(client: Client, callback: CallbackQuery) -> None:
    if not callback.data or not callback.data.startswith("rules:"):
        return
    action = callback.data.split(":")[1]
    if action == "accept":
        async with db.acquire() as conn:
            await conn.execute(
                "UPDATE users SET rules_accepted = TRUE, is_verified = TRUE, updated_at = now() WHERE telegram_id = $1",
                callback.from_user.id,
            )
        await callback.answer("Accepted")
        await callback.message.edit_text("Rules accepted.")
        await start_task_onboarding(client, callback.message)
    else:
        await callback.answer("Rejected")
        await callback.message.edit_text("Rules rejected. Task group link မရပါ။")


async def on_task_photo(client: Client, message: Message) -> None:
    if message.chat.type not in ("group", "supergroup") or not message.photo:
        return
    async with db.acquire() as conn:
        label = await conn.fetchval(
            "SELECT label FROM group_chat_map WHERE chat_id = $1", message.chat.id
        )
    if not label:
        return
    checker_group = await db.get_setting("checking_group_chat_id")
    topic_ref = await db.get_setting(f"checking_topic_{label}")
    if not checker_group:
        return
    caption = (
        f"Task photo from Group {label}\n"
        f"User: `{message.from_user.id}` @{message.from_user.username or '-'}\n"
        f"Caption: {message.caption or '-'}"
    )
    file_id = message.photo.file_id
    try:
        message_thread_id = None
        if topic_ref and str(topic_ref).isdigit():
            message_thread_id = int(topic_ref)
        elif topic_ref and "/c/" in str(topic_ref):
            try:
                message_thread_id = int(str(topic_ref).rstrip("/").split("/")[-1])
            except Exception:
                pass
        sent = await client.send_photo(
            chat_id=int(checker_group),
            photo=file_id,
            caption=caption,
            reply_markup=task_review_buttons(0),
            message_thread_id=message_thread_id,
        )
        async with db.acquire() as conn:
            row = await conn.fetchrow(
                """
                INSERT INTO photo_reviews
                    (telegram_id, chat_id, group_label, topic_id, photo_message_id,
                     review_chat_id, review_message_id, caption, track_date, status)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'pending')
                RETURNING id
                """,
                message.from_user.id, message.chat.id, label,
                message_thread_id or 0, message.id,
                sent.chat.id, sent.id, message.caption, date.today(),
            )
            review_id = row["id"]
        await client.edit_message_reply_markup(
            sent.chat.id, sent.id, reply_markup=task_review_buttons(review_id)
        )
    except Exception as e:
        log.exception("Failed to send photo review: %s", e)


async def on_task_review_callback(client: Client, callback: CallbackQuery) -> None:
    if not callback.data or not callback.data.startswith("task:"):
        return
    parts = callback.data.split(":")
    if len(parts) != 3:
        return
    action, rid_s = parts[1], parts[2]
    try:
        review_id = int(rid_s)
    except ValueError:
        return
    settings = get_settings()
    if not settings.is_admin(callback.from_user.id):
        checker = settings.check_group_id or await db.get_setting("checking_group_chat_id")
        if not checker or str(callback.message.chat.id) not in (
            str(checker), f"-100{str(checker).lstrip('-')}"
        ):
            await callback.answer("Checker only", show_alert=True)
            return

    async with db.transaction() as conn:
        review = await conn.fetchrow(
            "SELECT * FROM photo_reviews WHERE id = $1 AND status = 'pending' FOR UPDATE",
            review_id,
        )
        if not review:
            await callback.answer("Already resolved", show_alert=True)
            return
        new_status = "approved" if action == "approve" else "rejected"
        await conn.execute(
            "UPDATE photo_reviews SET status = $2, resolved_at = now() WHERE id = $1",
            review_id, new_status,
        )
        if new_status == "approved":
            await conn.execute(
                """
                INSERT INTO photo_tracking (telegram_id, chat_id, group_label, topic_id, track_date)
                VALUES ($1,$2,$3,$4,$5) ON CONFLICT DO NOTHING
                """,
                review["telegram_id"], review["chat_id"], review["group_label"],
                review["topic_id"], review["track_date"],
            )
    emoji = "OK" if action == "approve" else "X"
    try:
        await client.send_message(
            review["chat_id"], emoji, reply_to_message_id=review["photo_message_id"]
        )
    except Exception:
        pass
    await callback.message.edit_caption(
        (callback.message.caption or "") + f"\n\n{emoji} by {callback.from_user.first_name}",
        reply_markup=None,
    )
    await callback.answer(new_status)
    await db.audit(
        callback.from_user.id, f"task_{new_status}",
        target_id=review["telegram_id"], chat_id=review["chat_id"],
        metadata={"review_id": review_id},
    )


async def cmd_do(client: Client, message: Message) -> None:
    async with db.acquire() as conn:
        rows = await conn.fetch(
            "SELECT DISTINCT telegram_id FROM photo_tracking WHERE chat_id = $1 AND track_date = $2",
            message.chat.id, date.today(),
        )
    if not rows:
        await message.reply_text("ယနေ့ approved မရှိသေးပါ။")
        return
    await message.reply_text("ယနေ့ approved:\n" + "\n".join(f"`{r['telegram_id']}`" for r in rows))


async def cmd_ndo(client: Client, message: Message) -> None:
    async with db.acquire() as conn:
        members = await conn.fetch(
            "SELECT telegram_id FROM group_members WHERE chat_id = $1", message.chat.id
        )
        done = {
            r["telegram_id"]
            for r in await conn.fetch(
                "SELECT telegram_id FROM photo_tracking WHERE chat_id = $1 AND track_date = $2",
                message.chat.id, date.today(),
            )
        }
    missing = [m["telegram_id"] for m in members if m["telegram_id"] not in done]
    if not missing:
        await message.reply_text("အားလုံး approved ပြီးပါပြီ။")
        return
    await message.reply_text("မလုပ်ရသေးသူများ:\n" + "\n".join(f"`{x}`" for x in missing))
