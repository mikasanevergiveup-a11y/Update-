"""
Telegram Premium / custom emoji helpers.

HTML format (Bot API):
  <tg-emoji emoji-id="CUSTOM_ID">fallback</tg-emoji>

Requirements for the bot to *display* custom emoji to users:
  - Bot owner has Telegram Premium (Bot API 9.4+), OR
  - Bot has a Fragment collectible username assigned

Fill IDs in data/emoji_pack_emj_3c0e4.json after exporting from the pack:
  https://t.me/addemoji/emj_3c0e4_by_TgEmojis_bot

How to get IDs:
  1. Open https://t.me/emojigetida_bot (or any Get-Emoji-ID bot)
  2. Paste: https://t.me/addemoji/emj_3c0e4_by_TgEmojis_bot
  3. Copy each custom_emoji_id into the JSON under the matching role key
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Dict, Optional

log = logging.getLogger(__name__)

_PACK_PATH = Path(__file__).resolve().parents[2] / "data" / "emoji_pack_emj_3c0e4.json"
_ids: Dict[str, str] = {}
_loaded = False

# Semantic roles → fallback unicode (always works)
FALLBACK: Dict[str, str] = {
    "sparkle": "✨", "diamond": "💎", "music": "🎵", "user": "👤", "id": "🆔",
    "globe": "🌐", "star": "⭐", "lock": "🔒", "unlock": "🔓", "check": "✅", "cross": "❌",
    "wave": "👋", "hello": "👋", "fire": "🔥", "rocket": "🚀", "shield": "🛡",
    "clipboard": "📋", "gear": "⚙️", "bell": "🔔", "money": "💰", "photo": "📸",
    "play": "▶️", "pause": "⏸", "stop": "⏹", "skip": "⏭", "heart": "❤️",
    "warning": "⚠️", "party": "🎉", "search": "🔍", "back": "↩️", "chat": "💬",
    "channel": "📢", "clock": "⏳", "doc": "📜", "ping": "🏓", "stats": "📊",
    "key": "🔑", "gift": "🎁", "crown": "👑", "robot": "🤖", "link": "🔗",
    "trash": "🗑", "mic": "🎤", "volume": "🔊", "mute": "🔇", "download": "⬇️",
    "upload": "⬆️", "folder": "📂", "verify": "✅", "boost": "⬆️", "idea": "💡",
    "ban": "🚫", "like": "👍", "dislike": "👎", "clap": "👏",
    "lang": "🌐", "developer": "👨‍💻", "premium": "✨", "task": "📋", "help": "❓",
    "info": "ℹ️", "settings": "⚙️", "home": "🏠", "send": "📤", "copy": "📄",
    "edit": "✏️", "add": "➕", "list": "🗂", "filter": "🏷", "tag": "🏷",
    "share": "📤", "forward": "➡️", "reply": "↩️", "pin": "📌", "notify": "🔔",
    "camera": "📷", "video": "🎥", "call": "📞", "wallet": "💰", "shop": "🏪",
    "graph": "📈", "success": "✅", "error": "❌", "pending": "⏳",
    "profile": "👤", "admin": "⚙️", "terms": "📜", "agree": "✅", "disagree": "❌",
}


def _load() -> None:
    global _ids, _loaded
    if _loaded:
        return
    _loaded = True
    if not _PACK_PATH.exists():
        log.warning("Custom emoji pack file missing: %s", _PACK_PATH)
        return
    try:
        data = json.loads(_PACK_PATH.read_text(encoding="utf-8"))
        # data format: { "sparkle": "1234567890", ... } or { "roles": {...}, "all_ids": [...] }
        if "roles" in data:
            _ids = {k: str(v) for k, v in data["roles"].items() if v}
        else:
            _ids = {k: str(v) for k, v in data.items() if k != "all_ids" and v and not k.startswith("_")}
        log.info("Loaded %d custom emoji role mappings", len(_ids))
    except Exception as e:
        log.exception("Failed to load emoji pack: %s", e)


def ce(role: str, fallback: Optional[str] = None) -> str:
    """
    Return HTML custom-emoji tag if ID known, else unicode fallback.
    Use with parse_mode=HTML.
    """
    _load()
    fb = fallback or FALLBACK.get(role, "•")
    eid = _ids.get(role)
    if not eid:
        return fb
    return f'<tg-emoji emoji-id="{eid}">{fb}</tg-emoji>'


def has_custom(role: str) -> bool:
    _load()
    return bool(_ids.get(role))


def all_mapped() -> Dict[str, str]:
    _load()
    return dict(_ids)
