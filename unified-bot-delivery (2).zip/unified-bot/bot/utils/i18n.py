
"""Bilingual strings (my / en). All user-facing text goes through t(lang, key, **kw)."""
from __future__ import annotations
from typing import Any, Dict

STRINGS: Dict[str, Dict[str, str]] = {
    "en": {
        "welcome": (
            "{e_sparkle} <b>Welcome to Smart Hub Platform</b>\n\n"
            "All-in-one: Premium · Group Help · Task Groups · Music\n\n"
            "Choose a module below."
        ),
        "profile_title": "{e_clipboard} <b>Here is {name} detailed profile.</b>\n\nThis is your information stored by the bot.",
        "profile_table": (
            "<blockquote>"
            "👤 <b>User ID</b>  ·  <code>{uid}</code>\n"
            "🆔 <b>Username</b>  ·  {uname}\n"
            "🌐 <b>Language</b>  ·  {lang}\n"
            "✨ <b>Member Role</b>  ·  {role}\n"
            "{extra}"
            "</blockquote>"
        ),
        "premium_expire": "⏳ <b>Expires</b>  ·  {until}\n⏱ <b>Remaining</b>  ·  {hours}\n",
        "role_free": "Free",
        "role_premium": "Premium ✨",
        "lang_set": "✅ Language set to <b>English</b>",
        "choose_lang": "🌐 <b>Select language</b>",
        "supported_title": "{e_search} <b>Supported / Smart Hub Platform</b>\n\nJoin required channels & chat, then press Check.",
        "force_join": (
            "{e_lock} <b>Channel & Chat Force Join</b>\n\n"
            "Join all below, then press <b>✅ Check</b>."
        ),
        "check_ok": "{e_check} Check confirmed! Please read Terms & Agree.",
        "check_fail": "{e_cross} Please join all Channel & Chat first.",
        "terms_title": (
            "{e_doc} <b>Terms & Agree — Smart Hub Platform</b>\n\n"
            "Smart Hub Platform is an <b>(F2P)</b> platform.\n\n"
            "It cannot be defined as a job.\n\n"
            "By using Smart Hub Platform you must provide your Telegram Account Information and Location.\n\n"
            "If recruiters use the Smart Hub Platform name on any social media and charge entry fees, "
            "your Telegram information, phone number and location may be posted online.\n\n"
            "No 3rd party tools are allowed. Detection leads to ban.\n\n"
            "Ads will appear on Smart Hub Platform; you cannot complain about them.\n\n"
            "You must stay in related Channel & Chat.\n\n"
            "Insults or 18+ content in Channel/Chat will result in a ban.\n\n"
            "Any Error on Smart Hub Platform must be accepted.\n\n"
            "Do you agree?"
        ),
        "agree": "✅ I Agree",
        "disagree": "❌ I Disagree",
        "agree_next": (
            "{e_check} Thank you.\n\n"
            "To use <b>Smart Hub Platform</b>, press the button below."
        ),
        "disagree_bye": "{e_wave} Thank you. Goodbye.",
        "hub_btn": "🚀 Smart Hub Platform",
        "premium_menu": (
            "{e_diamond} <b>Premium Membership</b>\n\n"
            "Price: <b>{price} Ks / 24h</b>\n\n"
            "Benefits:\n"
            "• Priority support\n"
            "• Unlimited music\n"
            "• Advanced tools\n\n"
            "Choose payment method:"
        ),
        "pay_wave": "📱 Wave Pay",
        "pay_kpay": "📱 KPay",
        "pay_instr_wave": (
            "📱 <b>Wave Pay</b>\n\n"
            "Transfer <b>{price} Ks</b> to:\n"
            "<code>{phone}</code>\n\n"
            "Then send the <b>payment screenshot / proof</b> in this chat."
        ),
        "pay_instr_kpay": (
            "📱 <b>KPay</b>\n\n"
            "Transfer <b>{price} Ks</b> to:\n"
            "<code>{phone}</code>\n\n"
            "Then send the <b>payment screenshot / proof</b> in this chat."
        ),
        "receipt_ack": "✅ Receipt received. Admin is reviewing — please wait.",
        "pending_already": "{e_clock} You already have a pending receipt. Wait for admin.",
        "confirm_user": "{e_party} <b>Premium confirmed!</b>\nDuration: <b>{hours}h</b>\nEnjoy.",
        "reject_user": "{e_cross} Receipt rejected. Please send a valid payment proof or contact support.",
        "music_help": (
            "{e_music} <b>Music & Voice Chat</b>\n\n"
            "<b>Commands</b>\n"
            "• <code>/play song</code> — play in VC\n"
            "• <code>/vplay video</code> — video in VC\n"
            "• <code>/queue</code> — show queue\n"
            "• <code>/pause</code> <code>/resume</code> <code>/skip</code> <code>/stop</code>\n"
            "• <code>/volume 1-200</code>\n"
            "• <code>/song name</code> — download MP3\n"
            "• <code>/lyrics name</code>\n\n"
            "Open a Voice Chat in the group, then /play."
        ),
        "grouphelp_help": (
            "{e_shield} <b>Group Help</b>\n\n"
            "Admins can use moderation in groups:\n"
            "• Ban / Mute / Warn / Kick\n"
            "• Filters & Notes\n"
            "• Anti-link / Anti-channel\n"
            "• Welcome & Rules\n\n"
            "Type <code>/help</code> for user commands."
        ),
        "task_assigned": (
            "{e_check} You are assigned to <b>Task Group {group}</b>\n\n"
            "Join: {link}\n\n"
            "Send task photos in that group. Checker must approve."
        ),
        "help_user": (
            "{e_clipboard} <b>User Commands</b>\n\n"
            "<b>General</b>\n"
            "<code>/start</code> · <code>/help</code> · <code>/ping</code> · <code>/profile</code>\n\n"
            "<b>Premium</b>\n"
            "<code>/premium</code> — plans & payment\n"
            "Send payment <b>photo proof</b> in private\n\n"
            "<b>Music</b> (groups)\n"
            "<code>/play</code> <code>/vplay</code> <code>/queue</code> <code>/song</code> <code>/lyrics</code>\n\n"
            "<b>Group</b>\n"
            "<code>/rules</code> · <code>/get notename</code>\n\n"
            "Admin panel: <code>/helpadminpanel</code>"
        ),
        "admin_only": "{e_lock} Admin only.",
        "pong": "{e_ping} Pong! <code>{ms:.0f} ms</code>",
        "vc_not_ready": (
            "{e_warning} <b>Voice Chat not ready</b>\n\n"
            "Admin must set <code>STRING_SESSION</code> + <code>API_ID</code>/<code>API_HASH</code> and install ffmpeg.\n"
            "See docs/MUSIC_VC_SETUP.md"
        ),
        "searching": "{e_search} Searching…",
        "queued": "{e_check} Queued: <b>{title}</b>\nPosition: {pos}",
        "not_found": "{e_cross} Not found.",
        "vc_fail": "{e_cross} VC join/stream failed. Is Voice Chat open? Is user account in the group?",
        "check_user_found": "{e_check} User <code>{uid}</code> is registered.\nPremium: {prem}\nSeen: {seen}",
        "check_user_none": "{e_cross} User <code>{uid}</code> has not used this bot.",
        "broadcast_usage": "Reply to a message with /broadcast or /broadcast text",
        "no_phone": "Payment number not set yet. Contact admin.",
    },
    "my": {
        "welcome": (
            "{e_sparkle} <b>Smart Hub Platform မှ ကြိုဆိုပါတယ်</b>\n\n"
            "Premium · Group Help · Task Groups · Music\n\n"
            "အောက်က module တစ်ခု ရွေးပါ။"
        ),
        "profile_title": "{e_clipboard} <b>{name} ၏ အသေးစိတ် profile</b>\n\nBot ထဲ သိမ်းထားသော အချက်အလက်များ။",
        "profile_table": (
            "<blockquote>"
            "👤 <b>User ID</b>  ·  <code>{uid}</code>\n"
            "🆔 <b>Username</b>  ·  {uname}\n"
            "🌐 <b>ဘာသာ</b>  ·  {lang}\n"
            "✨ <b>အဆင့်</b>  ·  {role}\n"
            "{extra}"
            "</blockquote>"
        ),
        "premium_expire": "⏳ <b>ကုန်ဆုံး</b>  ·  {until}\n⏱ <b>ကျန်</b>  ·  {hours}\n",
        "role_free": "Free",
        "role_premium": "Premium ✨",
        "lang_set": "✅ ဘာသာစကားကို <b>မြန်မာ</b> သို့ ပြောင်းပြီးပါပြီ",
        "choose_lang": "🌐 <b>ဘာသာစကား ရွေးပါ</b>",
        "supported_title": "{e_search} <b>Supported / Smart Hub Platform</b>\n\nChannel & Chat join လုပ်ပြီး Check နှိပ်ပါ။",
        "force_join": (
            "{e_lock} <b>Channel & Chat Force Join</b>\n\n"
            "အောက်ပါအားလုံး join လုပ်ပြီး <b>✅ Check</b> နှိပ်ပါ။"
        ),
        "check_ok": "{e_check} Check အတည်ပြုပြီး! Terms & Agree ကို ဖတ်ပါ။",
        "check_fail": "{e_cross} Channel & Chat အားလုံး အရင် join လုပ်ပါ။",
        "terms_title": (
            "{e_doc} <b>Terms & Agree — Smart Hub Platform</b>\n\n"
            "Smart Hub Platform သည် <b>(F2P)</b> ပလက်ဖောင်းတစ်ခုဖြစ်သည်။\n\n"
            "အလုပ်ဟူ၍ မသတ်မှတ်နိုင်ပါ။\n\n"
            "Smart Hub Platform ကို အသုံးပြုခြင်းဖြင့် သင့်တို့၏ Telegram Account Information (အချက်အလက်) နှင့် Location (တည်နေရာ) ကို ပေးအပ်ရမည်ဖြစ်သည်။\n\n"
            "လူခေါ်သူများသည် Smart Hub Platform နာမည်ကို အသုံးပြုခြင်းဖြင့် ကျွန်ုပ်တို့၏အမည်ကို အသုံးပြု၍ မည်သည့် Social Media တွင်ဖြစ်စေ ၀င်ကြေးဖြင့် လိမ်လည်ခေါ်ယူပါက "
            "သင်တို့၏ Telegram Information ဖုန်းနံပါတ်နှင့်တကွ Location ဖြင့် လိုင်းပေါ်တွင် တင်မည်ဖြစ်ပါသည်။\n\n"
            "Smart Hub Platform ကိုအသုံးပြုရာတွင် မည်သည့် 3rd Party tools ကိုမှ အသုံးပြုခွင့်ရမည်မဟုတ်ပါ။ သိရှိပါက ban မည်ဖြစ်ပါသည်။\n\n"
            "Smart Hub Platform တွင် ကြော်ငြာများ တက်မည်ဖြစ်ပြီး ထိုအရာကို complain နိုင်ခွင့် သင်တို့၌ ရှိမည်မဟုတ်ပါ။\n\n"
            "Smart Hub Platform ကိုအသုံးပြုခြင်းဖြင့် Smart Hub platform နှင့် သက်ဆိုင်သော Channel & Chat များတွင် ရှိနေရမည်ဖြစ်သည်။\n\n"
            "Channel & Chat များအတွင်း၌ ဆဲဆိုခြင်း၊ 18+ များပေးပို့ခြင်း ပြုလုပ်ပါက ban ခံရမည်ဖြစ်သည်။\n\n"
            "Smart Hub Platform တွင် မည်သို့သော Error တက်စေကာမူ လက်ခံရမည်ဖြစ်သည်။\n\n"
            "အပေါ်က စည်းကမ်းများကို သဘောတူပါသလား?"
        ),
        "agree": "✅ သဘောတူညီပါသည်",
        "disagree": "❌ သဘောမတူညီပါ",
        "agree_next": (
            "{e_check} ကျေးဇူးတင်ပါသည်။\n\n"
            "Smart Hub Platform အား အသုံးပြုရန် အောက်ပါ ခလုတ်ကို နှိပ်ပါ။"
        ),
        "disagree_bye": "{e_wave} ကျေးဇူးတင်ပါတယ်။",
        "hub_btn": "🚀 Smart Hub Platform",
        "premium_menu": (
            "{e_diamond} <b>Premium Membership</b>\n\n"
            "ဈေး: <b>{price} ကျပ် / ၂၄ နာရီ</b>\n\n"
            "အကျိုးကျေးဇူး:\n"
            "• ဦးစားပေး support\n"
            "• Music အကန့်အသတ်မရှိ\n"
            "• ကိရိယာအဆင့်မြင့်\n\n"
            "ငွေပေးချေမှု နည်းလမ်း ရွေးပါ:"
        ),
        "pay_wave": "📱 Wave Pay",
        "pay_kpay": "📱 KPay",
        "pay_instr_wave": (
            "📱 <b>Wave Pay</b>\n\n"
            "<b>{price} ကျပ်</b> လွှဲပါ:\n"
            "<code>{phone}</code>\n\n"
            "ပြီးရင် ငွေလွှဲ <b>ပြေစာ / screenshot</b> ကို ဒီ chat ထဲ ပို့ပါ။"
        ),
        "pay_instr_kpay": (
            "📱 <b>KPay</b>\n\n"
            "<b>{price} ကျပ်</b> လွှဲပါ:\n"
            "<code>{phone}</code>\n\n"
            "ပြီးရင် ငွေလွှဲ <b>ပြေစာ / screenshot</b> ကို ဒီ chat ထဲ ပို့ပါ။"
        ),
        "receipt_ack": "{e_check} ပြေစာ လက်ခံရပါပြီ။ Admin စစ်ဆေးနေသည် — စောင့်ပါ။",
        "pending_already": "{e_clock} Pending ပြေစာ ရှိပြီးသားပါ။ Admin အဖြေ စောင့်ပါ။",
        "confirm_user": "{e_party} <b>Premium အတည်ပြုပြီး!</b>\nသက်တမ်း: <b>{hours} နာရီ</b>",
        "reject_user": "{e_cross} ပြေစာ ငြင်းပယ်ခံရပါသည်။ မှန်ကန်သော ပြေစာ ထပ်ပို့ပါ။",
        "music_help": (
            "{e_music} <b>Music & Voice Chat</b>\n\n"
            "<b>Commands</b>\n"
            "• <code>/play သီချင်း</code> — VC မှာ ဖွင့်\n"
            "• <code>/vplay ဗီဒီယို</code>\n"
            "• <code>/queue</code> — စာရင်း\n"
            "• <code>/pause</code> <code>/resume</code> <code>/skip</code> <code>/stop</code>\n"
            "• <code>/volume 1-200</code>\n"
            "• <code>/song</code> — MP3 ဒေါင်း\n"
            "• <code>/lyrics</code>\n\n"
            "Group မှာ Voice Chat ဖွင့်ပြီး /play သုံးပါ။"
        ),
        "grouphelp_help": (
            "{e_shield} <b>Group Help</b>\n\n"
            "Group admin များ:\n"
            "• Ban / Mute / Warn / Kick\n"
            "• Filters & Notes\n"
            "• Anti-link / Anti-channel\n"
            "• Welcome & Rules\n\n"
            "User commands အတွက် <code>/help</code>"
        ),
        "task_assigned": (
            "{e_check} သင့်ကို <b>Task Group {group}</b> သို့ ခွဲဝေပြီးပါပြီ\n\n"
            "Join: {link}\n\n"
            "အဲဒီ group ထဲ photo တင်ပါ။ Checker အတည်ပြုမှ ပြီးပါမည်။"
        ),
        "help_user": (
            "{e_clipboard} <b>User Commands</b>\n\n"
            "<b>အထွေထွေ</b>\n"
            "<code>/start</code> · <code>/help</code> · <code>/ping</code> · <code>/profile</code>\n\n"
            "<b>Premium</b>\n"
            "<code>/premium</code> — အစီအစဉ် & ငွေပေးချေ\n"
            "Private မှာ ငွေလွှဲ <b>ပုံ</b> ပို့ပါ\n\n"
            "<b>Music</b> (group)\n"
            "<code>/play</code> <code>/vplay</code> <code>/queue</code> <code>/song</code> <code>/lyrics</code>\n\n"
            "<b>Group</b>\n"
            "<code>/rules</code> · <code>/get notename</code>\n\n"
            "Admin: <code>/helpadminpanel</code>"
        ),
        "admin_only": "{e_lock} Admin သာ သုံးနိုင်သည်။",
        "pong": "{e_ping} Pong! <code>{ms:.0f} ms</code>",
        "vc_not_ready": (
            "{e_warning} <b>Voice Chat မအဆင်သင့်သေး</b>\n\n"
            "Admin က <code>STRING_SESSION</code> + API နှင့် ffmpeg တပ်ရမည်။"
        ),
        "searching": "{e_search} ရှာနေသည်…",
        "queued": "{e_check} စာရင်းသွင်းပြီး: <b>{title}</b>\nနေရာ: {pos}",
        "not_found": "{e_cross} မတွေ့ပါ။",
        "vc_fail": "{e_cross} VC ဝင်/stream မရပါ။ Voice Chat ဖွင့်ထားပါသလား?",
        "check_user_found": "{e_check} User <code>{uid}</code> မှတ်ပုံတင်ပြီး။\nPremium: {prem}\nLast seen: {seen}",
        "check_user_none": "{e_cross} User <code>{uid}</code> ဤ bot ကို မသုံးရသေးပါ။",
        "broadcast_usage": "စာ reply လုပ်ပြီး /broadcast သို့မဟုတ် /broadcast စာ",
        "no_phone": "ငွေလွှဲနံပါတ် မသတ်မှတ်ရသေးပါ။ Admin ဆက်သွယ်ပါ။",
    },
}


def t(lang: str, key: str, **kw: Any) -> str:
    lang = (lang or "my").lower()
    if lang.startswith("en"):
        lang = "en"
    else:
        lang = "my"
    bucket = STRINGS.get(lang) or STRINGS["my"]
    s = bucket.get(key) or STRINGS["en"].get(key) or key
    try:
        from bot.utils.custom_emoji import ce, FALLBACK
        # inject custom emoji for {e_role} placeholders
        for role in FALLBACK:
            token = "{e_" + role + "}"
            if token in s:
                s = s.replace(token, ce(role))
        if kw:
            s = s.format(**kw)
        return s
    except Exception:
        try:
            return s.format(**kw) if kw else s
        except Exception:
            return s


async def user_lang(telegram_id: int) -> str:
    try:
        from bot.database import db
        u = await db.get_user(telegram_id)
        if u and u.get("language_code"):
            lc = u["language_code"].lower()
            return "en" if lc.startswith("en") else "my"
    except Exception:
        pass
    return "my"
