"""Message helpers — design via HTML blockquote tables + i18n."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional

from bot.utils.i18n import t
from bot.utils.custom_emoji import ce


def _fmt_hours(hours: float) -> str:
    if hours <= 0:
        return "0h"
    h = int(hours)
    m = int((hours - h) * 60)
    if h >= 24:
        d = h // 24
        rem = h % 24
        return f"{d}d {rem}h"
    return f"{h}h {m}m" if m else f"{h}h"


def profile_card(user: Dict[str, Any], remaining: float = 0.0, lang: str = "my") -> str:
    uid = user.get("telegram_id", "—")
    uname = f"@{user['username']}" if user.get("username") else "—"
    lc = (user.get("language_code") or lang or "my").lower()
    lang_label = "English" if lc.startswith("en") else "မြန်မာ"
    role = t(lang, "role_premium") if user.get("is_premium") and remaining > 0 else t(lang, "role_free")
    name = user.get("full_name") or user.get("first_name") or uname
    extra = ""
    if remaining > 0:
        until = user.get("premium_until")
        until_str = until.strftime("%Y-%m-%d %H:%M") if isinstance(until, datetime) else "—"
        extra = (
            f"{ce('clock')} <b>{'Expires' if lang=='en' else 'ကုန်ဆုံး'}</b>  ·  {until_str}\n"
            f"{ce('clock')} <b>{'Remaining' if lang=='en' else 'ကျန်'}</b>  ·  {_fmt_hours(remaining)}\n"
        )
    title = t(lang, "profile_title", name=uname if uname != "—" else name)
    table = (
        f"<blockquote>"
        f"{ce('user')} <b>User ID</b>  ·  <code>{uid}</code>\n"
        f"{ce('id')} <b>Username</b>  ·  {uname}\n"
        f"{ce('globe')} <b>{'Language' if lang=='en' else 'ဘာသာ'}</b>  ·  {lang_label}\n"
        f"{ce('sparkle')} <b>{'Member Role' if lang=='en' else 'အဆင့်'}</b>  ·  {role}\n"
        f"{extra}"
        f"</blockquote>"
    )
    return f"{title}\n\n{table}"


def welcome_text(bot_username: str = "UnifiedBot", lang: str = "my") -> str:
    return t(lang, "welcome")


def help_text(lang: str = "my") -> str:
    return t(lang, "help_user")


def help_all_commands(lang: str = "my") -> str:
    return t(lang, "help_user")


def help_admin_panel() -> str:
    return (
        "⚙️ <b>Admin Panel</b>\n\n"
        "<b>Premium</b>\n"
        "<code>/setwave</code> <code>/setkpay</code> <code>/user</code>\n"
        "<code>/broadcast</code> · <code>/broadcastpreuser</code>\n\n"
        "<b>Task</b>\n"
        "<code>/setch</code> <code>/setc</code> <code>/setgp1-3</code>\n"
        "<code>/setcheckgroup</code> <code>/setchecktopic</code>\n\n"
        "<b>Moderation</b> (in groups)\n"
        "<code>/ban</code> <code>/mute</code> <code>/warn</code> <code>/pin</code> …\n\n"
        "<b>Check user</b>\n"
        "<code>/check userid</code>\n\n"
        "Env: ADMIN_TELEGRAM_IDS · STRING_SESSION · DATABASE_URL"
    )


def premium_start(wave: str = "—", kpay: str = "—", price: int = 200, lang: str = "my") -> str:
    return t(lang, "premium_menu", price=price)


def admin_stats(stats: Dict[str, int]) -> str:
    return (
        f"{ce('stats')} <b>User Stats</b>\n\n"
        f"{ce('user')} Total · <code>{stats.get('total', 0)}</code>\n"
        f"{ce('diamond')} Premium · <code>{stats.get('premium', 0)}</code>\n"
        f"{ce('clock')} Pending · <code>{stats.get('pending', 0)}</code>"
    )


def music_now_playing(title: str, duration: Optional[int], requester: str) -> str:
    dur = f"{duration // 60}:{duration % 60:02d}" if duration else "—"
    return (
        f"{ce('music')} <b>Now Playing</b>\n\n"
        f"<b>{title}</b>\n"
        f"{ce('clock')} {dur} · {ce('user')} {requester}"
    )


def confirm_user_msg(hours: int = 24, lang: str = "my") -> str:
    return t(lang, "confirm_user", hours=hours)


def reject_user_msg(lang: str = "my") -> str:
    return t(lang, "reject_user")


def receipt_ack(lang: str = "my") -> str:
    return t(lang, "receipt_ack")


def pending_already(lang: str = "my") -> str:
    return t(lang, "pending_already")
