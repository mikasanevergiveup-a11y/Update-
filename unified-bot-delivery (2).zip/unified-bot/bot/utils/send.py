"""Helpers for styled replies (Bot API 9.4 capsule buttons)."""
from __future__ import annotations

from typing import Any, Optional

from pyrogram.types import InlineKeyboardMarkup, Message


async def reply_html(
    message: Message,
    text: str,
    *,
    reply_markup: Optional[InlineKeyboardMarkup] = None,
    **kwargs: Any,
) -> Message:
    return await message.reply_text(
        text,
        parse_mode="html",
        reply_markup=reply_markup,
        **kwargs,
    )
