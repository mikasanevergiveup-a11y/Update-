# Admin Setup Guide

## 1. Create bot & get credentials
1. @BotFather → /newbot → save `BOT_TOKEN`
2. https://my.telegram.org → API development tools → `API_ID` + `API_HASH`
3. Put both + token into `.env`

## 2. Admin IDs
```env
ADMIN_TELEGRAM_IDS=123456789,987654321
```
Your numeric Telegram ID (forward message to @userinfobot).

## 3. Groups
1. Create **Admin group** (receipts) → add bot as admin → put ID in `ADMIN_GROUP_ID`
2. Create **Checker group** (with topics A/B/C if possible) → `CHECK_GROUP_ID` + `/setcheckgroup`
3. Create Task Groups A/B/C → register with `/setgp1` etc. and map via DB `group_chat_map` if needed
4. Disable privacy: @BotFather → /setprivacy → Disable (so bot sees all group messages)

## 4. Force-join
```
/setch -100xxxxxxxxxx https://t.me/+invite
/setc  -100yyyyyyyyyy https://t.me/+invite2
```

## 5. Premium numbers
In Admin group:
```
/setwave 09xxxxxxxxx
/setkpay 09xxxxxxxxx
```

## 6. Checker topics
```
/setcheckgroup -100zzzzzzzz
/setchecktopic A 123   # or t.me/c/.../message_id
/setchecktopic B ...
/setchecktopic C ...
```

## 7. Test flow
1. /start as normal user → force-join → rules → assignment
2. Send receipt photo in private → Confirm in Admin group
3. /profile shows Premium + remaining hours
4. In task group send photo → appears in checker → Approve
5. /play song in a group with VC

## 8. Permissions the bot needs
- Delete messages, restrict members, pin, invite users (for force-join checks)
- In VC groups: manage voice chats (for PyTgCalls)
