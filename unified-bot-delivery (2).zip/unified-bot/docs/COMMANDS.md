# Command Reference

## General
| Command | Scope | Description |
|---------|-------|-------------|
| /start | Private/Group | Welcome + main menu |
| /help | Any | All 4 modules commands & features |
| /helpadminpanel | Admin | Full admin panel command list |
| /ping | Any | Latency |
| /profile | Private | Dark profile card (screenshot style) |

## Premium
| Command | Scope | Description |
|---------|-------|-------------|
| /premium | Private | Plan + payment numbers |
| (photo) | Private | Submit payment receipt |
| /setwave | Admin | Set Wave number |
| /setkpay | Admin | Set KPay number |
| /user | Admin | Total / premium / pending counts |
| /broadcastpreuser | Admin | Broadcast to active premium users |

## Group Help (groups)
| Command | Description |
|---------|-------------|
| /ban /unban | Ban / unban user |
| /mute [time] /unmute | Mute (e.g. 1h) / unmute |
| /kick | Kick user |
| /warn /warns /rmwarn /resetwarns | Warning system |
| /pin /unpin | Pin / unpin |
| /del /purge | Delete / bulk delete |
| /setwelcome /welcomereset | Welcome message |
| /captcha on\|off | Captcha toggle |
| /antilink on\|off | Anti-link |
| /antichannel on\|off | Anti-channel posts |
| /setrules /rules | Rules |
| /filter /stop /filters | Keyword auto-replies |
| /save /get /clear | Notes (#name) |

## Task Groups
| Command | Scope | Description |
|---------|-------|-------------|
| /setch /setc | Admin | Force-join channel / chat |
| /setgp1 /setgp2 /setgp3 | Admin | Task group invite links |
| /setcheckgroup | Admin | Checker group ID |
| /setchecktopic A\|B\|C | Admin | Checker topic |
| /do /ndo | Task group | Today's approved / not-yet |

## Music (groups with VC)
| Command | Description |
|---------|-------------|
| /play [query\|url] | Play audio in VC |
| /vplay | Play video |
| /queue /q | Show queue |
| /pause /resume /skip /next /stop /end | Playback control |
| /mute /unmute | VC mute (via controls) |
| /volume 1-200 | Volume |
| /shuffle /loop | Queue options |
| /auth /unauth | Grant music control rights |
| /lyrics [name] | Lyrics search |
| /song [name] | Download MP3 |
| /video [name] | (extendable) Download video |

## BotFather menu suggestion
```
start - Start & main menu
help - Help modules
profile - Your profile
premium - Premium plan
play - Play music in VC
queue - Music queue
ban - Ban user
mute - Mute user
rules - Group rules
```
