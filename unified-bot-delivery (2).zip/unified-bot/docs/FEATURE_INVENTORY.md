# Feature Inventory — How each bot was merged

## 1. Group Task Bot (Python / aiogram / FastAPI)

| Original feature | Unified location | Notes |
|------------------|------------------|-------|
| `/start` force-join + Check | `task_group/handlers.py` + main | Channel + Chat |
| `/setch` `/setc` | task_group | Same commands |
| Rules accept/reject | task_group + keyboards | Same flow |
| Round-robin A/B/C | `db.next_task_group` | Same logic |
| `/setgp1-3` | task_group | Same |
| `/setcheckgroup` `/setchecktopic` | task_group | Same |
| Photo → checker topic | task_group `on_task_photo` | Same |
| ✓/× only then approved | task_group review callback + `FOR UPDATE` | Transaction-safe |
| `/do` `/ndo` | task_group | Same |
| Welcome / rules Premium Emoji | settings table (copy via reply planned) | Schema ready |
| Mini App challenge | Not ported in this cut (static/ still available from original if needed) | See KNOWN_LIMITATIONS |
| Broadcast / resetall | Premium module + audit | `/broadcastpreuser` + general broadcast can be extended |
| Schema | `migrations/001_initial_schema.sql` | Merged tables |

## 2. Smart Hub Premium (Node.js)

| Original feature | Unified location | Notes |
|------------------|------------------|-------|
| `/start` plan + Wave/KPay | premium + messages | Ported |
| Receipt photo → admin Confirm/Reject | premium handlers + DB | Transaction-safe, no auto-confirm |
| 24h premium | `PREMIUM_DEFAULT_HOURS=24` | Configurable |
| `/profile` | premium + screenshot-style card | Dark table UI |
| `/setwave` `/setkpay` | premium | Same |
| `/user` stats | premium | Same |
| `/broadcastpreuser` | premium | Same |
| Auto-expire | poller with lease | New, more robust |

## 3. Group Help / Management (from your specification)

All listed commands implemented in `group_help/handlers.py`:

- Moderation: ban, unban, mute, unmute, kick, warn system, pin, unpin, del, purge
- Settings: setwelcome, setrules, rules, captcha/antilink/antichannel toggles
- Filters & notes: filter, stop, filters, save, get, clear
- Anti-link / anti-channel message watcher
- Approved users table ready for whitelist extension

## 4. Music / VC (from your specification)

Implemented in `music/handlers.py`:

- play / vplay / queue / pause / resume / skip / stop
- volume / shuffle / loop / auth / unauth
- lyrics / song (download)
- Inline music controls
- Queue + DB persistence
- PyTgCalls hooks documented (full join/leave requires FFmpeg + runtime session)

## Conflicts resolved

- `/start` — single entry with module-aware main menu
- `/user` — premium stats (admin)
- `/profile` — unified profile card
- Settings keys namespaced in `bot_settings`
- Single `users` table for all modules
