# Known Limitations & Next Steps

1. **Music Voice Chat** — Implemented with Telegram **user account** + PyTgCalls.
   Requires `STRING_SESSION`, `API_ID`, `API_HASH`, and `ffmpeg`. See `docs/MUSIC_VC_SETUP.md`.

2. **Mini App / Challenge** — Intentionally **not** included (per owner request).

3. **/setw /setwel Premium Emoji copy** — Intentionally **not** included (per owner request).

4. **Broadcast** — Single unified `/broadcast` for all users + `/broadcastpreuser` for premium only.

5. **Night mode / anti-flood** — Settings flags exist; full scheduled lock can be extended.

6. **Task group map** — Map chat_id → A/B/C via SQL `group_chat_map` or ask for `/settaskgroup` command.

7. **Webhook mode** — Polling is default (VPS). Webhook optional later.

8. **Tests** — Smoke tests pass without live Telegram/DB.
