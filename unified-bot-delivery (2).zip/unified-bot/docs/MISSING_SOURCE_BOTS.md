# Missing Source Bots

At delivery time **no original ZIP source** was provided for:

- A separate “Music Bot” repository
- A separate “Group Help Bot” repository

Both modules were **implemented from the detailed command specifications you supplied in the follow-up message**, plus the UI screenshot.

No features were invented beyond:

1. Your written Group Help command list
2. Your written Music/VC command list
3. The two existing projects (Group Task + Smart Hub Premium)
4. The screenshot design language

If you later provide original Music or Group Help repositories, their exact command names / edge-case behavior can be diffed against this implementation and adjusted.
