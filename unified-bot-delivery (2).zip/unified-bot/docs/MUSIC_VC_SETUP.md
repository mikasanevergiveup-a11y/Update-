# Music Voice Chat Setup (Telegram User Account)

Real streaming uses a **user account** (not the bot) via Pyrogram + PyTgCalls.

## 1. Install system deps (VPS)

```bash
sudo apt update
sudo apt install -y ffmpeg
```

## 2. Python packages

```bash
pip install -r requirements.txt
# ensures: pyrogram, tgcrypto, pytgcalls, yt-dlp
```

## 3. Get API_ID / API_HASH

https://my.telegram.org → API development tools

```env
API_ID=12345678
API_HASH=your_hash
```

## 4. Create USER StringSession

On any machine with pyrogram:

```python
from pyrogram import Client

API_ID = 12345678
API_HASH = "your_hash"

with Client("gen", api_id=API_ID, api_hash=API_HASH, in_memory=True) as app:
    print(app.export_session_string())
```

Login with the **phone number of the account** that will join Voice Chats.

Put the printed string into `.env`:

```env
STRING_SESSION=1BVtsO...long_string...
```

**Security:** This is a full user login. Keep `.env` private. Prefer a dedicated secondary account.

## 5. Put the user account in groups

1. Add the user account to every group where music should play  
2. Start a Voice Chat in the group (or allow the account to create one)  
3. Bot can stay as group admin for commands; **streaming is done by the user account**

## 6. Run bot

```bash
python -m bot.main
```

Log should show:
```
VC user account online: Name (id)
PyTgCalls started
Music VC engine ready
```

## 7. Test

In a group with an active VC:
```
/play never gonna give you up
```

Controls: `/pause` `/resume` `/skip` `/stop` `/volume 80` `/queue`

## Troubleshooting

| Problem | Fix |
|---------|-----|
| VC not ready | STRING_SESSION empty or API_ID missing |
| join failed | User account not in group / no VC / banned |
| no sound | ffmpeg missing; check `ffmpeg -version` |
| Conflict getUpdates | Only one process should use the user session |
| pytgcalls error | Match pytgcalls version to pyrogram 2.x |

## Note

Bot token alone **cannot** join Telegram Voice Chats for streaming. A user account is required — that is why STRING_SESSION is mandatory for real VC.
