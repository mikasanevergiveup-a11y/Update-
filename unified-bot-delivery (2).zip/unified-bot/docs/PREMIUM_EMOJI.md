# Premium Custom Emoji

## Source (live IDs)

Catalog: https://emoji.wivvi.net/  
Pack: https://t.me/addemoji/tgiosicons  

`data/emoji_pack_emj_3c0e4.json` contains **51 real `custom_emoji_id` values** mapped to bot roles (sparkle, diamond, check, music, lock, …).

HTML in messages:
```html
<tg-emoji emoji-id="6028338546736107668">✨</tg-emoji>
```

Helper:
```python
from bot.utils.custom_emoji import ce
ce("check")  # → tg-emoji tag or unicode fallback
```

## Where used

- Welcome / profile table
- Force-join / Terms / Agree
- Premium confirm / reject
- Music now playing / queue messages
- Admin stats
- Help / errors / pong

## Requirement to see animated icons

- Bot owner account has **Telegram Premium**
- Bot API 9.4+
- Works in private, groups, supergroups

Without Premium on the owner account, clients show the unicode fallback inside the tag.

## Optional: your pack emj_3c0e4

To prefer https://t.me/addemoji/emj_3c0e4_by_TgEmojis_bot instead:

1. Export IDs via @emojigetida_bot  
2. Overwrite `roles` in `data/emoji_pack_emj_3c0e4.json`
