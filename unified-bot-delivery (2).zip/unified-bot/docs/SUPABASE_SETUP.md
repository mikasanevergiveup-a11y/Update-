# Supabase / PostgreSQL Setup

## 1. Create project
- https://supabase.com → New project
- Region close to users (e.g. Singapore)

## 2. Connection string
Project Settings → Database → Connection string → **Transaction pooler** (port **6543**)

```
postgresql://postgres.PROJECT_REF:PASSWORD@aws-0-REGION.pooler.supabase.com:6543/postgres
```

Put into `DATABASE_URL` in `.env`.

## 3. Run schema
SQL Editor → New query → paste entire `migrations/001_initial_schema.sql` → Run.

Or:
```bash
psql "$DATABASE_URL" -f migrations/001_initial_schema.sql
```

## 4. Verify
```sql
SELECT table_name FROM information_schema.tables WHERE table_schema = 'public';
```
You should see: users, bot_settings, premium_receipts, photo_reviews, music_queues, etc.

## 5. SSL
asyncpg works with Supabase pooler out of the box. If you hit SSL errors, append `?sslmode=require` to the URL.

## 6. Backups
Supabase dashboard → Database → Backups (Pro) or use `pg_dump`:
```bash
pg_dump "$DATABASE_URL" -Fc -f backup.dump
```

## 7. Migrations later
Add new files under `migrations/` (002_....sql) and run them in order. Keep them idempotent (`IF NOT EXISTS`).
