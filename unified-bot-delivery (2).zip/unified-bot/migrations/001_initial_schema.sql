-- ============================================================
-- Unified Bot — PostgreSQL / Supabase Schema
-- Run on a fresh database before first start.
-- ============================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------------------------------------------------------------------
-- Core users (merged from all bots)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    telegram_id         BIGINT PRIMARY KEY,
    username            TEXT,
    first_name          TEXT,
    last_name           TEXT,
    full_name           TEXT NOT NULL DEFAULT '',
    language_code       TEXT DEFAULT 'en',
    is_premium          BOOLEAN NOT NULL DEFAULT FALSE,
    premium_until       TIMESTAMPTZ,
    is_banned           BOOLEAN NOT NULL DEFAULT FALSE,
    ban_reason          TEXT,
    is_verified         BOOLEAN NOT NULL DEFAULT FALSE,
    force_join_done     BOOLEAN NOT NULL DEFAULT FALSE,
    rules_accepted      BOOLEAN NOT NULL DEFAULT FALSE,
    assigned_task_group TEXT CHECK (assigned_task_group IN ('A', 'B', 'C')),
    warns               INTEGER NOT NULL DEFAULT 0 CHECK (warns >= 0),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_users_username ON users (username);
CREATE INDEX IF NOT EXISTS idx_users_premium ON users (is_premium) WHERE is_premium = TRUE;
CREATE INDEX IF NOT EXISTS idx_users_premium_until ON users (premium_until) WHERE premium_until IS NOT NULL;

-- ---------------------------------------------------------------------
-- Bot-wide & per-chat settings (key-value + JSON)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS bot_settings (
    key        TEXT PRIMARY KEY,
    value      TEXT,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS chat_settings (
    chat_id        BIGINT PRIMARY KEY,
    welcome_text   TEXT,
    welcome_media  TEXT,          -- file_id
    captcha_on     BOOLEAN NOT NULL DEFAULT TRUE,
    antilink_on    BOOLEAN NOT NULL DEFAULT TRUE,
    antichannel_on BOOLEAN NOT NULL DEFAULT TRUE,
    antiflood_on   BOOLEAN NOT NULL DEFAULT TRUE,
    night_mode_on  BOOLEAN NOT NULL DEFAULT FALSE,
    night_start    TIME DEFAULT '22:00',
    night_end      TIME DEFAULT '07:00',
    max_warns      INTEGER NOT NULL DEFAULT 3,
    rules_text     TEXT,
    language       TEXT DEFAULT 'my',
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------
-- Premium payments & receipts
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS premium_receipts (
    id                   BIGSERIAL PRIMARY KEY,
    telegram_id          BIGINT NOT NULL REFERENCES users(telegram_id) ON DELETE CASCADE,
    status               TEXT NOT NULL DEFAULT 'pending'
                         CHECK (status IN ('pending', 'confirmed', 'rejected')),
    photo_file_id        TEXT NOT NULL,
    photo_file_unique_id TEXT,
    admin_message_id     BIGINT,
    admin_chat_id        BIGINT,
    reviewer_id          BIGINT,
    reviewed_at          TIMESTAMPTZ,
    premium_hours        INTEGER NOT NULL DEFAULT 24,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (telegram_id, photo_file_unique_id)
);

CREATE INDEX IF NOT EXISTS idx_premium_receipts_pending
    ON premium_receipts (status, created_at) WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS idx_premium_receipts_user
    ON premium_receipts (telegram_id, created_at DESC);

CREATE TABLE IF NOT EXISTS premium_transactions (
    id              BIGSERIAL PRIMARY KEY,
    telegram_id     BIGINT NOT NULL REFERENCES users(telegram_id) ON DELETE CASCADE,
    receipt_id      BIGINT REFERENCES premium_receipts(id),
    hours_added     INTEGER NOT NULL,
    premium_until   TIMESTAMPTZ NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------
-- Task-group module (ported from Group Task bot)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS round_robin_state (
    id      SMALLINT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    counter BIGINT NOT NULL DEFAULT 0 CHECK (counter >= 0)
);
INSERT INTO round_robin_state (id, counter) VALUES (1, 0)
ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS group_chat_map (
    chat_id BIGINT PRIMARY KEY,
    label   TEXT NOT NULL UNIQUE CHECK (label IN ('A', 'B', 'C'))
);

CREATE TABLE IF NOT EXISTS group_topics (
    chat_id     BIGINT NOT NULL,
    group_label TEXT NOT NULL CHECK (group_label IN ('A', 'B', 'C')),
    slot        SMALLINT NOT NULL CHECK (slot BETWEEN 1 AND 3),
    topic_id    BIGINT NOT NULL,
    topic_name  TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (chat_id, slot),
    UNIQUE (chat_id, topic_id)
);

CREATE TABLE IF NOT EXISTS pending_invite_messages (
    telegram_id  BIGINT NOT NULL REFERENCES users(telegram_id) ON DELETE CASCADE,
    group_label  TEXT NOT NULL CHECK (group_label IN ('A', 'B', 'C')),
    user_chat_id BIGINT NOT NULL,
    message_id   BIGINT NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (telegram_id, group_label)
);

CREATE TABLE IF NOT EXISTS group_members (
    id           BIGSERIAL PRIMARY KEY,
    telegram_id  BIGINT NOT NULL REFERENCES users(telegram_id) ON DELETE CASCADE,
    chat_id      BIGINT NOT NULL,
    group_label  TEXT NOT NULL CHECK (group_label IN ('A', 'B', 'C')),
    username     TEXT,
    joined_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (telegram_id, chat_id)
);

CREATE TABLE IF NOT EXISTS photo_reviews (
    id                BIGSERIAL PRIMARY KEY,
    telegram_id       BIGINT NOT NULL REFERENCES users(telegram_id) ON DELETE CASCADE,
    chat_id           BIGINT NOT NULL,
    group_label       TEXT NOT NULL CHECK (group_label IN ('A', 'B', 'C')),
    topic_id          BIGINT NOT NULL DEFAULT 0,
    photo_message_id  BIGINT NOT NULL,
    review_chat_id    BIGINT NOT NULL,
    review_message_id BIGINT NOT NULL,
    caption           TEXT,
    track_date        DATE NOT NULL,
    status            TEXT NOT NULL DEFAULT 'pending'
                      CHECK (status IN ('pending', 'approved', 'rejected')),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    resolved_at       TIMESTAMPTZ
);

CREATE UNIQUE INDEX IF NOT EXISTS photo_reviews_chat_message_key
    ON photo_reviews (review_chat_id, review_message_id);
CREATE INDEX IF NOT EXISTS idx_photo_reviews_pending
    ON photo_reviews (status, created_at) WHERE status = 'pending';

CREATE TABLE IF NOT EXISTS photo_tracking (
    id          BIGSERIAL PRIMARY KEY,
    telegram_id BIGINT NOT NULL REFERENCES users(telegram_id) ON DELETE CASCADE,
    chat_id     BIGINT NOT NULL,
    group_label TEXT NOT NULL CHECK (group_label IN ('A', 'B', 'C')),
    topic_id    BIGINT NOT NULL DEFAULT 0,
    track_date  DATE NOT NULL,
    sent_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (telegram_id, chat_id, topic_id, track_date)
);

-- ---------------------------------------------------------------------
-- Group Help / Moderation
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS warnings (
    id           BIGSERIAL PRIMARY KEY,
    chat_id      BIGINT NOT NULL,
    telegram_id  BIGINT NOT NULL,
    admin_id     BIGINT NOT NULL,
    reason       TEXT,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_warnings_user_chat ON warnings (chat_id, telegram_id);

CREATE TABLE IF NOT EXISTS approved_users (
    chat_id     BIGINT NOT NULL,
    telegram_id BIGINT NOT NULL,
    approved_by BIGINT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (chat_id, telegram_id)
);

CREATE TABLE IF NOT EXISTS filters (
    id         BIGSERIAL PRIMARY KEY,
    chat_id    BIGINT NOT NULL,
    trigger    TEXT NOT NULL,
    reply_text TEXT,
    reply_media TEXT,
    buttons    JSONB DEFAULT '[]',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (chat_id, trigger)
);

CREATE TABLE IF NOT EXISTS notes (
    id         BIGSERIAL PRIMARY KEY,
    chat_id    BIGINT NOT NULL,
    name       TEXT NOT NULL,
    content    TEXT NOT NULL,
    media      TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (chat_id, name)
);

CREATE TABLE IF NOT EXISTS flood_tracker (
    chat_id     BIGINT NOT NULL,
    telegram_id BIGINT NOT NULL,
    msg_count   INTEGER NOT NULL DEFAULT 1,
    window_start TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (chat_id, telegram_id)
);

-- ---------------------------------------------------------------------
-- Music / VC state
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS music_auth (
    chat_id     BIGINT NOT NULL,
    telegram_id BIGINT NOT NULL,
    granted_by  BIGINT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (chat_id, telegram_id)
);

CREATE TABLE IF NOT EXISTS music_queues (
    id          BIGSERIAL PRIMARY KEY,
    chat_id     BIGINT NOT NULL,
    title       TEXT NOT NULL,
    url         TEXT NOT NULL,
    duration    INTEGER,
    requested_by BIGINT,
    file_path   TEXT,
    is_video    BOOLEAN NOT NULL DEFAULT FALSE,
    position    INTEGER NOT NULL DEFAULT 0,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_music_queues_chat ON music_queues (chat_id, position);

-- ---------------------------------------------------------------------
-- Audit & broadcast logs
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admin_audit_logs (
    id                 BIGSERIAL PRIMARY KEY,
    admin_telegram_id  BIGINT NOT NULL,
    action             TEXT NOT NULL,
    target_telegram_id BIGINT,
    chat_id            BIGINT,
    metadata           JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS broadcast_logs (
    id          BIGSERIAL PRIMARY KEY,
    admin_id    BIGINT NOT NULL,
    target_type TEXT NOT NULL, -- all / premium / chat
    message     TEXT,
    sent        INTEGER NOT NULL DEFAULT 0,
    failed      INTEGER NOT NULL DEFAULT 0,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------
-- Poller / job checkpoints (idempotent background work)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS poller_checkpoints (
    job_name     TEXT PRIMARY KEY,
    last_run_at  TIMESTAMPTZ,
    lease_until  TIMESTAMPTZ,
    locked_by    TEXT,
    metadata     JSONB DEFAULT '{}'::jsonb
);

-- ---------------------------------------------------------------------
-- Helper: remaining premium hours view
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW user_premium_status AS
SELECT
    u.telegram_id,
    u.username,
    u.full_name,
    u.is_premium,
    u.premium_until,
    CASE
        WHEN u.premium_until IS NULL OR u.premium_until <= now() THEN 0
        ELSE EXTRACT(EPOCH FROM (u.premium_until - now())) / 3600.0
    END AS remaining_hours
FROM users u;
