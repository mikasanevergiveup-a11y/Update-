"""Smoke tests that do not require a live Telegram, database, or installed deps."""
from __future__ import annotations

import ast
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def test_imports_syntax():
    """All Python files under bot/ must parse."""
    bot_dir = ROOT / "bot"
    errors = []
    for path in bot_dir.rglob("*.py"):
        try:
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except SyntaxError as e:
            errors.append(f"{path}: {e}")
    assert not errors, "\n".join(errors)


def test_config_file_exists():
    path = ROOT / "bot" / "config.py"
    assert path.exists()
    tree = ast.parse(path.read_text(encoding="utf-8"))
    assert any(isinstance(n, ast.ClassDef) and n.name == "Settings" for n in tree.body)


def test_message_templates():
    # messages.py has no heavy deps
    from bot.utils.messages import profile_card, welcome_text, premium_start
    user = {
        "telegram_id": 123,
        "username": "testuser",
        "full_name": "Test User",
        "language_code": "en",
        "is_premium": False,
    }
    text = profile_card(user, 0)
    assert "User ID" in text
    assert "123" in text
    assert "Welcome" in welcome_text()
    assert "Premium" in premium_start()


def test_keyboards_importable():
    path = ROOT / "bot" / "keyboards" / "common.py"
    assert path.exists()
    ast.parse(path.read_text(encoding="utf-8"))


def test_schema_exists():
    schema = ROOT / "migrations" / "001_initial_schema.sql"
    assert schema.exists()
    content = schema.read_text(encoding="utf-8")
    assert "CREATE TABLE IF NOT EXISTS users" in content
    assert "premium_receipts" in content
    assert "photo_reviews" in content
    assert "music_queues" in content
